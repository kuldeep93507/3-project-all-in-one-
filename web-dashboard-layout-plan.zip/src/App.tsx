import { Toaster } from 'react-hot-toast';
import { useStore } from './store';
import TopBar from './components/Layout/TopBar';
import Sidebar from './components/Layout/Sidebar';
import Dashboard from './pages/Dashboard';
import Accounts from './pages/Accounts';
import Profiles from './pages/Profiles';
import Register from './pages/Register';
import EmailOTP from './pages/EmailOTP';
import Games from './pages/Games';
import Rewards from './pages/Rewards';
import Withdrawal from './pages/Withdrawal';
import Wallet from './pages/Wallet';
import Settings from './pages/Settings';

const pageMap: Record<string, React.ReactNode> = {
  dashboard: <Dashboard />,
  accounts: <Accounts />,
  profiles: <Profiles />,
  register: <Register />,
  email: <EmailOTP />,
  games: <Games />,
  rewards: <Rewards />,
  withdrawal: <Withdrawal />,
  wallet: <Wallet />,
  settings: <Settings />,
};

export default function App() {
  const { activeNav } = useStore();

  return (
    <div className="flex flex-col h-screen bg-gray-950 overflow-hidden">
      <Toaster
        position="top-right"
        toastOptions={{
          style: { background: '#1f2937', color: '#e5e7eb', border: '1px solid #374151' },
        }}
      />
      <TopBar />
      <div className="flex flex-1 overflow-hidden">
        <Sidebar />
        <main className="flex-1 flex overflow-hidden bg-gray-950 min-w-0">
          {pageMap[activeNav] || <Dashboard />}
        </main>
      </div>
    </div>
  );
}
