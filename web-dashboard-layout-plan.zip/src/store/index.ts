import { create } from 'zustand';
import { v4 as uuidv4 } from 'uuid';

export type Site = 'roobet.party' | 'gamdom.win' | 'stake.pet';
export type AccountStatus = 'Active' | 'Banned' | 'Unverified' | 'Archived' | 'Low Balance';
export type BotStatus = 'Running' | 'Stopped' | 'Error';
export type ProfileMode = 'multilogin' | 'direct';

export interface Account {
  id: string;
  site: Site;
  email: string;
  username: string;
  password: string;
  balance: number;
  status: AccountStatus;
  profileId: string;
  createdOn: string;
  lastActive: string;
  totalProfit: number;
  totalBets: number;
  totalWins: number;
}

export interface Profile {
  id: string;
  name: string;
  accountId: string;
  site: Site;
  balance: number;
  activeGame: string;
  botStatus: BotStatus;
  serverHash: string;
  clientSeed: string;
  cdpPort: number;
  sessionToken: string;
  profit: number;
  bets: number;
  wins: number;
}

export interface BetResult {
  id: string;
  site: Site;
  profile: string;
  account: string;
  game: string;
  betAmount: number;
  target: number;
  result: 'WIN' | 'LOSS';
  profit: number;
  time: string;
}

export interface RegisterAccount {
  id: string;
  email: string;
  username: string;
  password: string;
  site: Site;
  status: 'Pending' | 'Registering' | 'Email Pending' | 'Done' | 'Failed';
}

export interface EmailOTP {
  id: string;
  email: string;
  site: Site;
  accountId: string;
  status: 'Pending' | 'Verified';
  otp: string;
}

export interface RewardClaim {
  id: string;
  profileId: string;
  site: Site;
  type: 'Vault' | 'Rakeback' | 'Daily' | 'Weekly' | 'Monthly';
  amount: number;
  time: string;
  status: 'Pending' | 'Claimed' | 'Failed';
}

export interface Withdrawal {
  id: string;
  profileId: string;
  site: Site;
  amount: number;
  currency: string;
  address: string;
  time: string;
  status: 'Pending' | 'Submitted' | 'Confirmed' | 'Failed';
}

export interface Notification {
  id: string;
  type: 'profit' | 'ban' | 'stop' | 'reward' | 'error';
  message: string;
  time: string;
  read: boolean;
}

export interface BetSettings {
  betAmount: number;
  targetMultiplier: number;
  strategy: 'OFF' | 'Martingale' | 'Anti-Martingale' | 'Fibonacci' | "D'Alembert";
  martingaleMultiplier: number;
  martingaleMaxSteps: number;
  stopOnProfit: number;
  stopOnLoss: number;
  maxBets: number;
  stopOnProfitEnabled: boolean;
  stopOnLossEnabled: boolean;
}

export interface Settings {
  multilogin: {
    email: string;
    password: string;
    apiUrl: string;
  };
  smartproxy: {
    username: string;
    password: string;
    host: string;
    port: number;
  };
  roobet: {
    baseUrl: string;
    defaultBet: number;
    defaultMultiplier: number;
    withdrawalAddress: string;
  };
  gamdom: {
    baseUrl: string;
    defaultBet: number;
    defaultMultiplier: number;
  };
  stake: {
    baseUrl: string;
    defaultBet: number;
    defaultMultiplier: number;
  };
  notifications: {
    browser: boolean;
    profitAlert: boolean;
    lossAlert: boolean;
    botStop: boolean;
    banAlert: boolean;
  };
  seedRotator: {
    rotateAfterBets: number;
    rotateOnConsecutiveLosses: number;
    rotateOnConsecutiveWins: number;
    neverReuse: boolean;
  };
  healthMonitor: {
    checkEveryMinutes: number;
    alertOnBan: boolean;
    alertOnSessionExpire: boolean;
    autoRelogin: boolean;
  };
}

export interface RewardSettings {
  vault: { enabled: boolean; threshold: number };
  rakeback: { enabled: boolean; everyHours: number };
  daily: { enabled: boolean };
  weekly: { enabled: boolean };
  monthly: { enabled: boolean };
}

interface AppStore {
  activeSite: Site;
  activeNav: string;
  profileMode: ProfileMode;
  multiloginConnected: boolean;

  accounts: Account[];
  profiles: Profile[];
  betResults: BetResult[];
  registerAccounts: RegisterAccount[];
  emailOTPs: EmailOTP[];
  rewardClaims: RewardClaim[];
  withdrawals: Withdrawal[];
  notifications: Notification[];
  settings: Settings;
  rewardSettings: RewardSettings;
  betSettings: BetSettings;

  setActiveSite: (site: Site) => void;
  setActiveNav: (nav: string) => void;
  setProfileMode: (mode: ProfileMode) => void;
  setMultiloginConnected: (v: boolean) => void;

  addAccount: (account: Account) => void;
  updateAccount: (id: string, data: Partial<Account>) => void;
  archiveAccount: (id: string) => void;

  addProfile: (profile: Profile) => void;
  updateProfile: (id: string, data: Partial<Profile>) => void;
  removeProfile: (id: string) => void;
  startBot: (profileId: string) => void;
  stopBot: (profileId: string) => void;
  rotateSeeds: (profileIds: string[]) => void;

  addBetResult: (result: BetResult) => void;
  clearBetResults: () => void;

  addRegisterAccount: (acc: RegisterAccount) => void;
  updateRegisterAccount: (id: string, data: Partial<RegisterAccount>) => void;
  removeRegisterAccount: (id: string) => void;

  addEmailOTP: (otp: EmailOTP) => void;
  updateEmailOTP: (id: string, data: Partial<EmailOTP>) => void;

  addRewardClaim: (claim: RewardClaim) => void;
  addWithdrawal: (w: Withdrawal) => void;

  addNotification: (n: Omit<Notification, 'id' | 'time' | 'read'>) => void;
  markAllNotificationsRead: () => void;

  updateSettings: (s: Partial<Settings>) => void;
  updateBetSettings: (s: Partial<BetSettings>) => void;
  updateRewardSettings: (s: Partial<RewardSettings>) => void;
}

const generateHash = () => Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 12);
const generateSeed = () => Math.random().toString(36).substring(2, 10).toUpperCase() + Math.random().toString(36).substring(2, 10);

const mockAccounts: Account[] = [
  { id: '1', site: 'roobet.party', email: 'raju67678@gmail.com', username: 'raju67678', password: 'Pass@123', balance: 12.45, status: 'Active', profileId: 'p1', createdOn: '2024-01-15', lastActive: '2024-01-20', totalProfit: 45.23, totalBets: 234, totalWins: 127 },
  { id: '2', site: 'roobet.party', email: 'priya99@gmail.com', username: 'priya99', password: 'Secure#456', balance: 0.12, status: 'Low Balance', profileId: 'p2', createdOn: '2024-01-10', lastActive: '2024-01-19', totalProfit: -12.50, totalBets: 89, totalWins: 41 },
  { id: '3', site: 'gamdom.win', email: 'snake_king@yahoo.com', username: 'snake_king', password: 'Abc!789', balance: 8.90, status: 'Active', profileId: 'p3', createdOn: '2024-01-12', lastActive: '2024-01-20', totalProfit: 28.70, totalBets: 156, totalWins: 82 },
  { id: '4', site: 'gamdom.win', email: 'banned_user@gmail.com', username: 'banned_user', password: 'Old@pass1', balance: 0, status: 'Banned', profileId: 'p4', createdOn: '2024-01-05', lastActive: '2024-01-14', totalProfit: -5.00, totalBets: 45, totalWins: 21 },
  { id: '5', site: 'stake.pet', email: 'crypto_lord@gmail.com', username: 'crypto_lord', password: 'Stake#321', balance: 25.60, status: 'Active', profileId: 'p5', createdOn: '2024-01-08', lastActive: '2024-01-20', totalProfit: 89.10, totalBets: 312, totalWins: 178 },
  { id: '6', site: 'stake.pet', email: 'high_roller@outlook.com', username: 'high_roller', password: 'Roll!654', balance: 3.20, status: 'Unverified', profileId: 'p6', createdOn: '2024-01-18', lastActive: '2024-01-18', totalProfit: 0, totalBets: 0, totalWins: 0 },
];

const mockProfiles: Profile[] = [
  { id: 'p1', name: 'Profile Alpha', accountId: '1', site: 'roobet.party', balance: 12.45, activeGame: 'Limbo', botStatus: 'Running', serverHash: 'abc123def456ghi', clientSeed: 'DWXZr9bKqM', cdpPort: 9222, sessionToken: 'inersc2a2k_abc', profit: 45.23, bets: 234, wins: 127 },
  { id: 'p2', name: 'Profile Beta', accountId: '2', site: 'roobet.party', balance: 0.12, activeGame: 'Dice', botStatus: 'Stopped', serverHash: 'xyz789uvw012pqr', clientSeed: 'FGHIjkl123', cdpPort: 9223, sessionToken: 'inersc2a2k_def', profit: -12.50, bets: 89, wins: 41 },
  { id: 'p3', name: 'Profile Gamma', accountId: '3', site: 'gamdom.win', balance: 8.90, activeGame: 'Crash', botStatus: 'Running', serverHash: 'mnop456qrst789', clientSeed: 'MNOPqrst45', cdpPort: 9224, sessionToken: '', profit: 28.70, bets: 156, wins: 82 },
  { id: 'p4', name: 'Profile Delta', accountId: '4', site: 'gamdom.win', balance: 0, activeGame: '', botStatus: 'Error', serverHash: 'abc123def456ghi', clientSeed: 'UVWXyz6789', cdpPort: 9225, sessionToken: '', profit: -5.00, bets: 45, wins: 21 },
  { id: 'p5', name: 'Profile Epsilon', accountId: '5', site: 'stake.pet', balance: 25.60, activeGame: 'Mines', botStatus: 'Running', serverHash: 'stk999aaa111bbb', clientSeed: 'ABCdef0123', cdpPort: 9226, sessionToken: 'inersc2a2k_ghi', profit: 89.10, bets: 312, wins: 178 },
  { id: 'p6', name: 'Profile Zeta', accountId: '6', site: 'stake.pet', balance: 3.20, activeGame: '', botStatus: 'Stopped', serverHash: 'zzz888yyy777xxx', clientSeed: 'GHIjkl6789', cdpPort: 9227, sessionToken: '', profit: 0, bets: 0, wins: 0 },
];

const mockBetResults: BetResult[] = Array.from({ length: 20 }, (_, i) => ({
  id: uuidv4(),
  site: ['roobet.party', 'gamdom.win', 'stake.pet'][i % 3] as Site,
  profile: ['Profile Alpha', 'Profile Gamma', 'Profile Epsilon'][i % 3],
  account: ['raju67678', 'snake_king', 'crypto_lord'][i % 3],
  game: ['Limbo', 'Dice', 'Mines', 'Crash', 'Roulette'][i % 5],
  betAmount: 0.01,
  target: [1.01, 2.00, 2.00][i % 3],
  result: i % 3 === 0 ? 'LOSS' : 'WIN',
  profit: i % 3 === 0 ? -0.01 : 0.01 * [1.01, 2.00, 2.00][i % 3] - 0.01,
  time: new Date(Date.now() - i * 3000).toLocaleTimeString(),
}));

const mockRewardClaims: RewardClaim[] = [
  { id: '1', profileId: 'p1', site: 'roobet.party', type: 'Vault', amount: 2.50, time: '2024-01-20 08:00', status: 'Claimed' },
  { id: '2', profileId: 'p3', site: 'gamdom.win', type: 'Rakeback', amount: 1.20, time: '2024-01-20 10:00', status: 'Claimed' },
  { id: '3', profileId: 'p5', site: 'stake.pet', type: 'Daily', amount: 0.80, time: '2024-01-20 00:00', status: 'Claimed' },
];

export const useStore = create<AppStore>((set, get) => ({
  activeSite: 'roobet.party',
  activeNav: 'dashboard',
  profileMode: 'multilogin',
  multiloginConnected: true,

  accounts: mockAccounts,
  profiles: mockProfiles,
  betResults: mockBetResults,
  registerAccounts: [
    { id: uuidv4(), email: 'new_user1@gmail.com', username: 'new_user1', password: 'Test@123', site: 'roobet.party', status: 'Pending' },
    { id: uuidv4(), email: 'new_user2@gmail.com', username: 'new_user2', password: 'Test@456', site: 'gamdom.win', status: 'Email Pending' },
  ],
  emailOTPs: [
    { id: uuidv4(), email: 'new_user1@gmail.com', site: 'roobet.party', accountId: '', status: 'Pending', otp: '' },
    { id: uuidv4(), email: 'new_user2@gmail.com', site: 'gamdom.win', accountId: '', status: 'Pending', otp: '' },
  ],
  rewardClaims: mockRewardClaims,
  withdrawals: [],
  notifications: [
    { id: '1', type: 'profit', message: 'Profile Alpha hit profit target $50!', time: '10:30', read: false },
    { id: '2', type: 'ban', message: 'Account banned_user has been banned on gamdom.win', time: '09:15', read: false },
    { id: '3', type: 'reward', message: 'Vault claimed: $2.50 from roobet.party', time: '08:00', read: true },
  ],

  settings: {
    multilogin: { email: 'admin@roobetbot.com', password: 'mlx_password', apiUrl: 'http://localhost:35000' },
    smartproxy: { username: 'smart-pwgbkxcy3lyi', password: 'xEdCpOSFn3nd4ixu', host: 'us.smartproxy.net', port: 3120 },
    roobet: { baseUrl: 'roobet.party', defaultBet: 0.01, defaultMultiplier: 1.01, withdrawalAddress: '0x4E490b8871C874b84935e6128A21595C2Dd5710d' },
    gamdom: { baseUrl: 'gamdom.win', defaultBet: 0.01, defaultMultiplier: 2.00 },
    stake: { baseUrl: 'stake.pet', defaultBet: 0.01, defaultMultiplier: 2.00 },
    notifications: { browser: true, profitAlert: true, lossAlert: true, botStop: true, banAlert: true },
    seedRotator: { rotateAfterBets: 100, rotateOnConsecutiveLosses: 10, rotateOnConsecutiveWins: 20, neverReuse: false },
    healthMonitor: { checkEveryMinutes: 5, alertOnBan: true, alertOnSessionExpire: true, autoRelogin: false },
  },

  rewardSettings: {
    vault: { enabled: true, threshold: 5 },
    rakeback: { enabled: true, everyHours: 4 },
    daily: { enabled: true },
    weekly: { enabled: true },
    monthly: { enabled: true },
  },

  betSettings: {
    betAmount: 0.01,
    targetMultiplier: 1.01,
    strategy: 'Martingale',
    martingaleMultiplier: 2,
    martingaleMaxSteps: 6,
    stopOnProfit: 10,
    stopOnLoss: 5,
    maxBets: 0,
    stopOnProfitEnabled: true,
    stopOnLossEnabled: true,
  },

  setActiveSite: (site) => set({ activeSite: site }),
  setActiveNav: (nav) => set({ activeNav: nav }),
  setProfileMode: (mode) => set({ profileMode: mode }),
  setMultiloginConnected: (v) => set({ multiloginConnected: v }),

  addAccount: (account) => set((s) => ({ accounts: [...s.accounts, account] })),
  updateAccount: (id, data) => set((s) => ({ accounts: s.accounts.map(a => a.id === id ? { ...a, ...data } : a) })),
  archiveAccount: (id) => set((s) => ({ accounts: s.accounts.map(a => a.id === id ? { ...a, status: 'Archived' } : a) })),

  addProfile: (profile) => set((s) => ({ profiles: [...s.profiles, profile] })),
  updateProfile: (id, data) => set((s) => ({ profiles: s.profiles.map(p => p.id === id ? { ...p, ...data } : p) })),
  removeProfile: (id) => set((s) => ({ profiles: s.profiles.filter(p => p.id !== id) })),
  startBot: (profileId) => {
    set((s) => ({ profiles: s.profiles.map(p => p.id === profileId ? { ...p, botStatus: 'Running' } : p) }));
    const profile = get().profiles.find(p => p.id === profileId);
    if (profile) {
      const interval = setInterval(() => {
        const isWin = Math.random() > 0.5;
        const betAmt = get().betSettings.betAmount;
        const target = get().betSettings.targetMultiplier;
        const profit = isWin ? betAmt * (target - 1) : -betAmt;
        get().addBetResult({
          id: uuidv4(),
          site: profile.site,
          profile: profile.name,
          account: get().accounts.find(a => a.id === profile.accountId)?.username || '',
          game: profile.activeGame || 'Limbo',
          betAmount: betAmt,
          target,
          result: isWin ? 'WIN' : 'LOSS',
          profit,
          time: new Date().toLocaleTimeString(),
        });
        get().updateProfile(profileId, {
          profit: (get().profiles.find(p => p.id === profileId)?.profit || 0) + profit,
          bets: (get().profiles.find(p => p.id === profileId)?.bets || 0) + 1,
          wins: (get().profiles.find(p => p.id === profileId)?.wins || 0) + (isWin ? 1 : 0),
          balance: Math.max(0, (get().profiles.find(p => p.id === profileId)?.balance || 0) + profit),
        });
        if (get().profiles.find(p => p.id === profileId)?.botStatus !== 'Running') {
          clearInterval(interval);
        }
      }, 2000);
    }
  },
  stopBot: (profileId) => set((s) => ({ profiles: s.profiles.map(p => p.id === profileId ? { ...p, botStatus: 'Stopped', activeGame: '' } : p) })),
  rotateSeeds: (profileIds) => set((s) => ({
    profiles: s.profiles.map(p => profileIds.includes(p.id) ? { ...p, serverHash: generateHash(), clientSeed: generateSeed() } : p)
  })),

  addBetResult: (result) => set((s) => ({ betResults: [result, ...s.betResults].slice(0, 100) })),
  clearBetResults: () => set({ betResults: [] }),

  addRegisterAccount: (acc) => set((s) => ({ registerAccounts: [...s.registerAccounts, acc] })),
  updateRegisterAccount: (id, data) => set((s) => ({ registerAccounts: s.registerAccounts.map(a => a.id === id ? { ...a, ...data } : a) })),
  removeRegisterAccount: (id) => set((s) => ({ registerAccounts: s.registerAccounts.filter(a => a.id !== id) })),

  addEmailOTP: (otp) => set((s) => ({ emailOTPs: [...s.emailOTPs, otp] })),
  updateEmailOTP: (id, data) => set((s) => ({ emailOTPs: s.emailOTPs.map(o => o.id === id ? { ...o, ...data } : o) })),

  addRewardClaim: (claim) => set((s) => ({ rewardClaims: [claim, ...s.rewardClaims] })),
  addWithdrawal: (w) => set((s) => ({ withdrawals: [w, ...s.withdrawals] })),

  addNotification: (n) => set((s) => ({
    notifications: [{ ...n, id: uuidv4(), time: new Date().toLocaleTimeString(), read: false }, ...s.notifications]
  })),
  markAllNotificationsRead: () => set((s) => ({ notifications: s.notifications.map(n => ({ ...n, read: true })) })),

  updateSettings: (s) => set((state) => ({ settings: { ...state.settings, ...s } })),
  updateBetSettings: (s) => set((state) => ({ betSettings: { ...state.betSettings, ...s } })),
  updateRewardSettings: (s) => set((state) => ({ rewardSettings: { ...state.rewardSettings, ...s } })),
}));
