import { useState } from 'react';
import { Bell, ChevronDown, Zap, CheckCheck } from 'lucide-react';
import { useStore, Site } from '../../store';

const sites: Site[] = ['roobet.party', 'gamdom.win', 'stake.pet'];

const siteColors: Record<Site, string> = {
  'roobet.party': 'text-yellow-400',
  'gamdom.win': 'text-green-400',
  'stake.pet': 'text-blue-400',
};

const siteBg: Record<Site, string> = {
  'roobet.party': 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300',
  'gamdom.win': 'bg-green-500/20 border-green-500/50 text-green-300',
  'stake.pet': 'bg-blue-500/20 border-blue-500/50 text-blue-300',
};

export default function TopBar() {
  const { activeSite, setActiveSite, notifications, markAllNotificationsRead } = useStore();
  const [showNotif, setShowNotif] = useState(false);
  const [showSiteDrop, setShowSiteDrop] = useState(false);
  const unread = notifications.filter(n => !n.read).length;

  return (
    <header className="h-14 bg-gray-900 border-b border-gray-700/60 flex items-center px-4 gap-4 z-50 relative">
      {/* Logo */}
      <div className="flex items-center gap-2 min-w-[180px]">
        <div className="w-8 h-8 bg-yellow-500 rounded-lg flex items-center justify-center shadow-lg shadow-yellow-500/30">
          <Zap className="w-5 h-5 text-black" fill="currentColor" />
        </div>
        <span className="font-bold text-white text-sm tracking-wide">ROOBET BOT</span>
        <span className="text-xs text-yellow-400 font-mono bg-yellow-500/10 px-1.5 py-0.5 rounded border border-yellow-500/30">v2.0</span>
      </div>

      {/* Site Switcher */}
      <div className="flex items-center gap-2 flex-1">
        {/* Primary site dropdown */}
        <div className="relative">
          <button
            onClick={() => setShowSiteDrop(!showSiteDrop)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-lg border text-sm font-medium transition-all ${siteBg[activeSite]}`}
          >
            <div className={`w-2 h-2 rounded-full bg-current animate-pulse`} />
            {activeSite}
            <ChevronDown className="w-3.5 h-3.5" />
          </button>
          {showSiteDrop && (
            <div className="absolute top-full left-0 mt-1 bg-gray-800 border border-gray-600 rounded-lg shadow-xl overflow-hidden z-50 min-w-[160px]">
              {sites.map(site => (
                <button
                  key={site}
                  onClick={() => { setActiveSite(site); setShowSiteDrop(false); }}
                  className={`w-full text-left px-3 py-2.5 text-sm flex items-center gap-2 hover:bg-gray-700 transition-colors ${activeSite === site ? 'bg-gray-700' : ''}`}
                >
                  <div className={`w-2 h-2 rounded-full ${activeSite === site ? 'bg-green-400 animate-pulse' : 'bg-gray-500'}`} />
                  <span className={siteColors[site]}>{site}</span>
                  {activeSite === site && <span className="ml-auto text-xs text-gray-400">Active</span>}
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Quick site switchers */}
        {sites.filter(s => s !== activeSite).map(site => (
          <button
            key={site}
            onClick={() => setActiveSite(site)}
            className="px-3 py-1.5 rounded-lg bg-gray-800 border border-gray-700 text-xs text-gray-400 hover:text-white hover:border-gray-500 transition-all"
          >
            {site}
          </button>
        ))}
      </div>

      {/* Status indicators */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1.5 text-xs text-gray-400">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          <span>3 Bots Running</span>
        </div>

        {/* Notification Bell */}
        <div className="relative">
          <button
            onClick={() => { setShowNotif(!showNotif); if (!showNotif) markAllNotificationsRead(); }}
            className="relative w-9 h-9 rounded-lg bg-gray-800 border border-gray-700 flex items-center justify-center hover:border-gray-500 transition-all group"
          >
            <Bell className="w-4.5 h-4.5 text-gray-400 group-hover:text-white transition-colors" />
            {unread > 0 && (
              <span className="absolute -top-1 -right-1 w-4.5 h-4.5 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-bold">
                {unread}
              </span>
            )}
          </button>

          {showNotif && (
            <div className="absolute top-full right-0 mt-1 w-80 bg-gray-800 border border-gray-600 rounded-xl shadow-2xl z-50 overflow-hidden">
              <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700">
                <span className="font-semibold text-white text-sm">Notifications</span>
                <button onClick={markAllNotificationsRead} className="text-xs text-gray-400 hover:text-white flex items-center gap-1">
                  <CheckCheck className="w-3.5 h-3.5" /> Mark all read
                </button>
              </div>
              <div className="max-h-72 overflow-y-auto">
                {notifications.length === 0 ? (
                  <div className="px-4 py-6 text-center text-gray-500 text-sm">No notifications</div>
                ) : notifications.map(n => (
                  <div key={n.id} className={`px-4 py-3 border-b border-gray-700/50 ${!n.read ? 'bg-gray-700/30' : ''}`}>
                    <div className="flex items-start gap-2">
                      <div className={`w-2 h-2 rounded-full mt-1.5 flex-shrink-0 ${n.type === 'profit' ? 'bg-green-400' : n.type === 'ban' ? 'bg-red-400' : n.type === 'stop' ? 'bg-yellow-400' : 'bg-blue-400'}`} />
                      <div className="flex-1 min-w-0">
                        <p className="text-xs text-gray-200 leading-relaxed">{n.message}</p>
                        <p className="text-[10px] text-gray-500 mt-0.5">{n.time}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Click outside */}
      {(showNotif || showSiteDrop) && (
        <div className="fixed inset-0 z-40" onClick={() => { setShowNotif(false); setShowSiteDrop(false); }} />
      )}
    </header>
  );
}
