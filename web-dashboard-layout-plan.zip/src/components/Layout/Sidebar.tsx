import { useStore } from '../../store';

const navItems = [
  { id: 'dashboard', icon: '🏠', label: 'Dashboard' },
  { id: 'accounts', icon: '👤', label: 'Accounts' },
  { id: 'profiles', icon: '🦊', label: 'Profiles' },
  { id: 'register', icon: '📝', label: 'Register' },
  { id: 'email', icon: '📧', label: 'Email / OTP' },
  { id: 'games', icon: '🎮', label: 'Games' },
  { id: 'rewards', icon: '🎁', label: 'Rewards' },
  { id: 'withdrawal', icon: '💸', label: 'Withdrawal' },
  { id: 'wallet', icon: '💰', label: 'Wallet' },
  { id: 'settings', icon: '⚙️', label: 'Settings' },
];

export default function Sidebar() {
  const { activeNav, setActiveNav, profiles, accounts } = useStore();

  const runningBots = profiles.filter(p => p.botStatus === 'Running').length;
  const bannedAccounts = accounts.filter(a => a.status === 'Banned').length;

  return (
    <aside className="w-16 hover:w-52 transition-all duration-300 group bg-gray-900 border-r border-gray-700/60 flex flex-col overflow-hidden shrink-0">
      <nav className="flex-1 py-4 flex flex-col gap-1 px-2">
        {navItems.map(item => {
          const isActive = activeNav === item.id;
          const hasBadge = item.id === 'accounts' && bannedAccounts > 0;
          const hasRunning = item.id === 'profiles' && runningBots > 0;
          return (
            <button
              key={item.id}
              onClick={() => setActiveNav(item.id)}
              className={`flex items-center gap-3 px-2.5 py-2.5 rounded-xl text-left transition-all duration-200 relative
                ${isActive
                  ? 'bg-yellow-500/15 text-yellow-300 border border-yellow-500/30 shadow-sm'
                  : 'text-gray-400 hover:text-white hover:bg-gray-800 border border-transparent'
                }`}
            >
              <span className="text-xl shrink-0 w-6 text-center">{item.icon}</span>
              <span className="text-sm font-medium whitespace-nowrap overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity duration-200 max-w-0 group-hover:max-w-xs">
                {item.label}
              </span>
              {hasBadge && (
                <span className="absolute top-1.5 right-1.5 w-3.5 h-3.5 bg-red-500 rounded-full text-[8px] text-white flex items-center justify-center font-bold">
                  {bannedAccounts}
                </span>
              )}
              {hasRunning && !isActive && (
                <span className="absolute top-2 right-2 w-2 h-2 bg-green-400 rounded-full animate-pulse" />
              )}
            </button>
          );
        })}
      </nav>

      {/* Bottom info */}
      <div className="px-2 pb-4">
        <div className="px-2.5 py-2.5 rounded-xl bg-gray-800/50 border border-gray-700/50">
          <div className="flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse shrink-0" />
            <span className="text-[10px] text-gray-400 whitespace-nowrap overflow-hidden opacity-0 group-hover:opacity-100 transition-opacity duration-200">
              {runningBots} bot{runningBots !== 1 ? 's' : ''} running
            </span>
          </div>
        </div>
      </div>
    </aside>
  );
}
