import { useState } from 'react';
import { Play, Square, RefreshCw, AlertTriangle } from 'lucide-react';
import { useStore } from '../store';
import type { Site } from '../store';

type GameDef = { name: string; emoji: string; url: string };

const GAMES: Record<Site, GameDef[]> = {
  'roobet.party': [
    { name: 'Limbo', emoji: '🚀', url: 'roobet.party/casino/game/limbo' },
    { name: 'Dice', emoji: '🎲', url: 'roobet.party/casino/game/dice' },
    { name: 'Mines', emoji: '💣', url: 'roobet.party/casino/game/mines' },
    { name: 'Roulette', emoji: '🎡', url: 'roobet.party/casino/game/roulette' },
    { name: 'Baccarat', emoji: '🃏', url: 'roobet.party/casino/game/baccarat' },
  ],
  'gamdom.win': [
    { name: 'Limbo', emoji: '🚀', url: 'gamdom.win/limbo' },
    { name: 'Dice', emoji: '🎲', url: 'gamdom.win/dice' },
    { name: 'Mines', emoji: '💣', url: 'gamdom.win/mines' },
    { name: 'Crash', emoji: '📈', url: 'gamdom.win/crash' },
    { name: 'Roulette', emoji: '🎡', url: 'gamdom.win/roulette' },
    { name: 'Blackjack', emoji: '♠️', url: 'gamdom.win/blackjack' },
    { name: 'Plinko', emoji: '🎯', url: 'gamdom.win/plinko' },
    { name: 'Keno', emoji: '🔢', url: 'gamdom.win/keno' },
    { name: 'HiLo', emoji: '📊', url: 'gamdom.win/hilo' },
    { name: 'Pocket Dice', emoji: '🎰', url: 'gamdom.win/pocket-dice' },
    { name: 'Twist', emoji: '🌀', url: 'gamdom.win/twist' },
  ],
  'stake.pet': [
    { name: 'Limbo', emoji: '🚀', url: 'stake.pet/casino/games/limbo' },
    { name: 'Dice', emoji: '🎲', url: 'stake.pet/casino/games/dice' },
    { name: 'Mines', emoji: '💣', url: 'stake.pet/casino/games/mines' },
    { name: 'Crash', emoji: '📈', url: 'stake.pet/casino/games/crash' },
    { name: 'Plinko', emoji: '🎯', url: 'stake.pet/casino/games/plinko' },
    { name: 'Keno', emoji: '🔢', url: 'stake.pet/casino/games/keno' },
    { name: 'HiLo', emoji: '📊', url: 'stake.pet/casino/games/hilo' },
    { name: 'Roulette', emoji: '🎡', url: 'stake.pet/casino/games/roulette' },
    { name: 'Baccarat', emoji: '🃏', url: 'stake.pet/casino/games/baccarat' },
    { name: 'Blackjack', emoji: '♠️', url: 'stake.pet/casino/games/blackjack' },
    { name: 'Wheel', emoji: '🎡', url: 'stake.pet/casino/games/wheel' },
    { name: 'Dragon Tower', emoji: '🐉', url: 'stake.pet/casino/games/dragon-tower' },
    { name: 'Chicken', emoji: '🐔', url: 'stake.pet/casino/games/chicken' },
    { name: 'Flip', emoji: '🪙', url: 'stake.pet/casino/games/flip' },
    { name: 'Pump', emoji: '⛽', url: 'stake.pet/casino/games/pump' },
    { name: 'Snakes', emoji: '🐍', url: 'stake.pet/casino/games/snakes' },
    { name: 'Primedice', emoji: '🎰', url: 'stake.pet/casino/games/primedice' },
    { name: 'Video Poker', emoji: '🃏', url: 'stake.pet/casino/games/video-poker' },
  ],
};

const generateSeed = () => Math.random().toString(36).substring(2, 10).toUpperCase() + Math.random().toString(36).substring(2, 10);
const generateHash = () => Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 12);

export default function Games() {
  const { activeSite, profiles, betResults, startBot, stopBot, rotateSeeds, updateProfile, betSettings, updateBetSettings } = useStore();
  const [selectedGame, setSelectedGame] = useState<GameDef | null>(null);
  const [selectedProfiles, setSelectedProfiles] = useState<string[]>([]);

  const siteProfiles = profiles.filter(p => p.site === activeSite);
  const games = GAMES[activeSite];

  const toggleProfile = (id: string) => setSelectedProfiles(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const toggleAllProfiles = () => setSelectedProfiles(selectedProfiles.length === siteProfiles.length ? [] : siteProfiles.map(p => p.id));

  const handleGameClick = (game: GameDef) => {
    setSelectedGame(game);
    selectedProfiles.forEach(id => updateProfile(id, { activeGame: game.name }));
  };

  const handleStart = () => {
    if (!selectedGame) return;
    selectedProfiles.forEach(id => {
      updateProfile(id, { activeGame: selectedGame.name });
      startBot(id);
    });
  };

  const handleStop = () => {
    selectedProfiles.forEach(id => stopBot(id));
  };

  const winChance = betSettings.targetMultiplier > 0 ? ((1 / betSettings.targetMultiplier) * 100).toFixed(2) : '0.00';
  const potentialPayout = (betSettings.betAmount * betSettings.targetMultiplier).toFixed(4);

  const profileHashMap: Record<string, string[]> = {};
  siteProfiles.forEach(p => {
    if (!profileHashMap[p.serverHash]) profileHashMap[p.serverHash] = [];
    profileHashMap[p.serverHash].push(p.name);
  });
  const dupHashes = Object.entries(profileHashMap).filter(([, names]) => names.length > 1);

  const liveFeed = betResults.filter(b => b.site === activeSite);

  return (
    <div className="flex-1 flex overflow-hidden">
      {/* Left: Game tiles + Profile selector */}
      <div className="flex-1 overflow-y-auto p-5 space-y-5 min-w-0">
        <div>
          <h1 className="text-2xl font-bold text-white">Games</h1>
          <p className="text-gray-400 text-sm mt-1">Select profiles + game → bots navigate to game URL</p>
        </div>

        {/* Profile Selector */}
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="font-semibold text-sm text-white">Select Profiles ({selectedProfiles.length} selected)</span>
            <button onClick={toggleAllProfiles} className="text-xs text-yellow-400 hover:text-yellow-300">
              {selectedProfiles.length === siteProfiles.length ? 'Deselect All' : 'Select All'}
            </button>
          </div>
          <div className="flex flex-wrap gap-2">
            {siteProfiles.map(p => {
              const isSelected = selectedProfiles.includes(p.id);
              return (
                <button
                  key={p.id}
                  onClick={() => toggleProfile(p.id)}
                  className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${isSelected ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-700/50 border-gray-600/50 text-gray-400 hover:text-white'}`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full ${p.botStatus === 'Running' ? 'bg-green-400 animate-pulse' : p.botStatus === 'Error' ? 'bg-red-400' : 'bg-gray-500'}`} />
                  {p.name}
                </button>
              );
            })}
          </div>
        </div>

        {/* Seed Duplicate Alert */}
        {dupHashes.length > 0 && (
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-3 space-y-1">
            {dupHashes.map(([hash, names]) => (
              <div key={hash} className="flex items-center gap-2 text-xs text-red-400">
                <AlertTriangle className="w-4 h-4 shrink-0" />
                ⚠️ Profile {names.join(' & ')} ka Server Hash same hai! ({hash.slice(0, 8)}...)
              </div>
            ))}
          </div>
        )}

        {/* Game Tiles */}
        <div>
          <h2 className="font-semibold text-white mb-3 text-sm">🎮 Games — {activeSite}</h2>
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 xl:grid-cols-6 gap-3">
            {games.map(game => (
              <button
                key={game.name}
                onClick={() => handleGameClick(game)}
                className={`p-3 rounded-xl border text-center transition-all ${selectedGame?.name === game.name ? 'bg-yellow-500/20 border-yellow-500/60 shadow-lg shadow-yellow-500/10' : 'bg-gray-800/50 border-gray-700/50 hover:border-gray-500 hover:bg-gray-700/50'}`}
              >
                <div className="text-2xl mb-1">{game.emoji}</div>
                <div className="text-xs font-medium text-gray-300">{game.name}</div>
                {selectedGame?.name === game.name && <div className="text-[10px] text-yellow-400 mt-1">SELECTED</div>}
              </button>
            ))}
          </div>
        </div>

        {selectedGame && (
          <div className="text-xs text-gray-500 font-mono bg-gray-800/30 rounded-lg px-3 py-2 flex items-center gap-2">
            <span>URL:</span>
            <span className="text-blue-400">https://{selectedGame.url}</span>
          </div>
        )}

        {/* Live Results Feed */}
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-white text-sm flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Live Results Feed
            </h2>
            <button onClick={() => {}} className="text-xs text-gray-400 hover:text-white">Clear</button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-[11px]">
              <thead>
                <tr className="border-b border-gray-700/50">
                  {['Site', 'Profile', 'Account', 'Game', 'Bet$', 'Target', 'Result', 'Profit', 'Time'].map(h => (
                    <th key={h} className="text-left px-2 py-1.5 text-gray-500 font-medium">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {liveFeed.slice(0, 20).map(b => (
                  <tr key={b.id} className={`border-b border-gray-700/20 ${b.result === 'WIN' ? 'bg-green-500/5' : 'bg-red-500/5'}`}>
                    <td className="px-2 py-1.5 text-gray-500">{b.site.split('.')[0]}</td>
                    <td className="px-2 py-1.5 text-gray-300">{b.profile}</td>
                    <td className="px-2 py-1.5 text-gray-400">{b.account}</td>
                    <td className="px-2 py-1.5 text-gray-300">{b.game}</td>
                    <td className="px-2 py-1.5 text-gray-300 font-mono">${b.betAmount.toFixed(2)}</td>
                    <td className="px-2 py-1.5 text-gray-400 font-mono">{b.target}x</td>
                    <td className={`px-2 py-1.5 font-semibold ${b.result === 'WIN' ? 'text-green-400' : 'text-red-400'}`}>{b.result}</td>
                    <td className={`px-2 py-1.5 font-mono font-semibold ${b.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {b.profit >= 0 ? '+' : ''}${b.profit.toFixed(4)}
                    </td>
                    <td className="px-2 py-1.5 text-gray-600">{b.time}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            {liveFeed.length === 0 && (
              <div className="text-center py-6 text-gray-500 text-sm">No bets yet. Start a bot to see live results.</div>
            )}
          </div>
        </div>
      </div>

      {/* Right: Bet Settings Panel */}
      <div className="w-72 shrink-0 border-l border-gray-700/50 overflow-y-auto p-4 space-y-5 bg-gray-900/30">
        <h2 className="font-semibold text-white">⚙️ Bet Settings</h2>

        {/* Basic */}
        <div className="space-y-3">
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Bet Amount ($)</label>
            <input
              type="number"
              value={betSettings.betAmount}
              onChange={e => updateBetSettings({ betAmount: Number(e.target.value) })}
              step="0.01"
              min="0.01"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white outline-none focus:border-yellow-500/50"
            />
          </div>
          <div>
            <label className="text-xs text-gray-400 mb-1 block">Target Multiplier</label>
            <input
              type="number"
              value={betSettings.targetMultiplier}
              onChange={e => updateBetSettings({ targetMultiplier: Number(e.target.value) })}
              step="0.01"
              min="1.01"
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white outline-none focus:border-yellow-500/50"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <div className="bg-gray-800/50 rounded-lg px-3 py-2">
              <div className="text-[10px] text-gray-500">Win Chance</div>
              <div className="text-sm font-mono text-yellow-400">{winChance}%</div>
            </div>
            <div className="bg-gray-800/50 rounded-lg px-3 py-2">
              <div className="text-[10px] text-gray-500">Payout</div>
              <div className="text-sm font-mono text-green-400">${potentialPayout}</div>
            </div>
          </div>
        </div>

        {/* Strategy */}
        <div className="space-y-2 border-t border-gray-700/50 pt-4">
          <label className="text-xs text-gray-400">Strategy</label>
          <select
            value={betSettings.strategy}
            onChange={e => updateBetSettings({ strategy: e.target.value as any })}
            className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-lg text-sm text-white outline-none"
          >
            {['OFF', 'Martingale', 'Anti-Martingale', "D'Alembert", 'Fibonacci'].map(s => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
          {betSettings.strategy === 'Martingale' && (
            <div className="space-y-2">
              <div>
                <label className="text-[10px] text-gray-500">Multiplier on Loss</label>
                <input type="number" value={betSettings.martingaleMultiplier} onChange={e => updateBetSettings({ martingaleMultiplier: Number(e.target.value) })} step="0.5" min="1.5" className="w-full px-2 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-white outline-none mt-1" />
              </div>
              <div>
                <label className="text-[10px] text-gray-500">Max Steps (then reset)</label>
                <input type="number" value={betSettings.martingaleMaxSteps} onChange={e => updateBetSettings({ martingaleMaxSteps: Number(e.target.value) })} min="1" max="20" className="w-full px-2 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-white outline-none mt-1" />
              </div>
            </div>
          )}
        </div>

        {/* Stop Conditions */}
        <div className="space-y-2 border-t border-gray-700/50 pt-4">
          <label className="text-xs text-gray-400">Stop Conditions</label>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <input type="checkbox" checked={betSettings.stopOnProfitEnabled} onChange={e => updateBetSettings({ stopOnProfitEnabled: e.target.checked })} className="accent-yellow-500" />
              <label className="text-[10px] text-gray-500">Stop on Profit ($)</label>
            </div>
            <input type="number" value={betSettings.stopOnProfit} onChange={e => updateBetSettings({ stopOnProfit: Number(e.target.value) })} disabled={!betSettings.stopOnProfitEnabled} min="0" className="w-full px-2 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-white outline-none disabled:opacity-40" />
          </div>
          <div>
            <div className="flex items-center gap-2 mb-1">
              <input type="checkbox" checked={betSettings.stopOnLossEnabled} onChange={e => updateBetSettings({ stopOnLossEnabled: e.target.checked })} className="accent-yellow-500" />
              <label className="text-[10px] text-gray-500">Stop on Loss ($)</label>
            </div>
            <input type="number" value={betSettings.stopOnLoss} onChange={e => updateBetSettings({ stopOnLoss: Number(e.target.value) })} disabled={!betSettings.stopOnLossEnabled} min="0" className="w-full px-2 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-white outline-none disabled:opacity-40" />
          </div>
          <div>
            <label className="text-[10px] text-gray-500">Max Bets (0 = ∞)</label>
            <input type="number" value={betSettings.maxBets} onChange={e => updateBetSettings({ maxBets: Number(e.target.value) })} min="0" className="w-full px-2 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-white outline-none mt-1" />
          </div>
        </div>

        {/* Seeds */}
        <div className="border-t border-gray-700/50 pt-4 space-y-3">
          <div className="flex items-center justify-between">
            <label className="text-xs text-gray-400">Seeds (per profile)</label>
            <button
              onClick={() => rotateSeeds(selectedProfiles.length > 0 ? selectedProfiles : siteProfiles.map(p => p.id))}
              className="flex items-center gap-1 text-[10px] text-purple-400 hover:text-purple-300 transition-colors"
            >
              <RefreshCw className="w-3 h-3" /> Rotate All
            </button>
          </div>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {siteProfiles.filter(p => selectedProfiles.length === 0 || selectedProfiles.includes(p.id)).map(p => (
              <div key={p.id} className="bg-gray-800/50 rounded-lg p-2 space-y-1">
                <div className="text-[10px] text-gray-500 font-medium">{p.name}</div>
                <div className="flex items-center gap-1">
                  <span className="text-[9px] text-gray-600 w-14">Srv Hash:</span>
                  <input value={p.serverHash} onChange={e => updateProfile(p.id, { serverHash: e.target.value })} className="flex-1 px-1.5 py-0.5 bg-gray-700/50 rounded text-[9px] text-gray-300 font-mono outline-none min-w-0" />
                  <button onClick={() => updateProfile(p.id, { serverHash: generateHash() })} className="text-gray-500 hover:text-yellow-400"><RefreshCw className="w-2.5 h-2.5" /></button>
                </div>
                <div className="flex items-center gap-1">
                  <span className="text-[9px] text-gray-600 w-14">Cli Seed:</span>
                  <input value={p.clientSeed} onChange={e => updateProfile(p.id, { clientSeed: e.target.value })} className="flex-1 px-1.5 py-0.5 bg-gray-700/50 rounded text-[9px] text-gray-300 font-mono outline-none min-w-0" />
                  <button onClick={() => updateProfile(p.id, { clientSeed: generateSeed() })} className="text-gray-500 hover:text-yellow-400"><RefreshCw className="w-2.5 h-2.5" /></button>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="space-y-2 border-t border-gray-700/50 pt-4">
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleStart}
              disabled={selectedProfiles.length === 0 || !selectedGame}
              className="flex items-center justify-center gap-1.5 py-2.5 bg-green-500 hover:bg-green-400 text-black text-xs font-bold rounded-xl transition-colors disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <Play className="w-3.5 h-3.5" /> Start
            </button>
            <button
              onClick={handleStop}
              disabled={selectedProfiles.length === 0}
              className="flex items-center justify-center gap-1.5 py-2.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs font-semibold rounded-xl border border-red-500/30 transition-colors disabled:opacity-40"
            >
              <Square className="w-3.5 h-3.5" /> Stop
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={handleStart}
              className="flex items-center justify-center gap-1.5 py-2 bg-green-500/10 hover:bg-green-500/20 text-green-400 text-[10px] rounded-xl border border-green-500/20 transition-colors"
            >
              <Play className="w-3 h-3" /> Start All
            </button>
            <button
              onClick={() => siteProfiles.forEach(p => stopBot(p.id))}
              className="flex items-center justify-center gap-1.5 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 text-[10px] rounded-xl border border-red-500/20 transition-colors"
            >
              <Square className="w-3 h-3" /> Stop All
            </button>
          </div>
          {(!selectedGame || selectedProfiles.length === 0) && (
            <p className="text-[10px] text-gray-500 text-center">
              {!selectedGame && 'Select a game'}{!selectedGame && selectedProfiles.length === 0 && ' & '}{selectedProfiles.length === 0 && 'Select profiles'} to start
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
