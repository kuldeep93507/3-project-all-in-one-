import { useState } from 'react';
import { useStore } from '../store';
import { Check, X, Eye, EyeOff } from 'lucide-react';

function Toggle({ value, onChange }: { value: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`relative inline-flex w-10 h-5.5 items-center rounded-full transition-colors ${value ? 'bg-yellow-500' : 'bg-gray-600'}`}
    >
      <span className={`inline-block w-4 h-4 transform rounded-full bg-white shadow transition-transform ${value ? 'translate-x-5.5' : 'translate-x-0.5'}`} />
    </button>
  );
}

function Field({ label, value, onChange, type = 'text', placeholder, monospace }: { label: string; value: string | number; onChange: (v: string) => void; type?: string; placeholder?: string; monospace?: boolean }) {
  const [show, setShow] = useState(false);
  const isPassword = type === 'password';
  return (
    <div>
      <label className="text-xs text-gray-400 mb-1.5 block">{label}</label>
      <div className="relative">
        <input
          type={isPassword && !show ? 'password' : 'text'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className={`w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none focus:border-yellow-500/50 ${monospace ? 'font-mono text-xs' : ''} ${isPassword ? 'pr-9' : ''}`}
        />
        {isPassword && (
          <button onClick={() => setShow(!show)} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-white">
            {show ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        )}
      </div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-5 space-y-4">
      <h3 className="font-semibold text-white text-sm border-b border-gray-700/50 pb-3">{title}</h3>
      {children}
    </div>
  );
}

function TestButton({ label }: { label: string; onTest?: () => void }) {
  const [status, setStatus] = useState<'idle' | 'testing' | 'success' | 'fail'>('idle');
  const handleTest = () => {
    setStatus('testing');
    setTimeout(() => setStatus(Math.random() > 0.3 ? 'success' : 'fail'), 1500);
  };
  return (
    <button
      onClick={handleTest}
      className={`flex items-center gap-1.5 px-3 py-2 text-xs rounded-lg border transition-all ${status === 'success' ? 'bg-green-500/20 text-green-400 border-green-500/40' : status === 'fail' ? 'bg-red-500/20 text-red-400 border-red-500/40' : 'bg-gray-700 text-gray-300 border-gray-600 hover:border-gray-500'}`}
    >
      {status === 'testing' && <div className="w-3 h-3 border border-current border-t-transparent rounded-full animate-spin" />}
      {status === 'success' && <Check className="w-3 h-3" />}
      {status === 'fail' && <X className="w-3 h-3" />}
      {status === 'idle' ? label : status === 'testing' ? 'Testing...' : status === 'success' ? 'Connected!' : 'Failed'}
    </button>
  );
}

export default function Settings() {
  const { settings, updateSettings } = useStore();

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-white">Settings</h1>
        <p className="text-gray-400 text-sm mt-1">Configure all integrations and preferences</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-5">
        {/* Multilogin */}
        <Section title="🦊 Multilogin X Config">
          <Field label="Email" value={settings.multilogin.email} onChange={v => updateSettings({ multilogin: { ...settings.multilogin, email: v } })} />
          <Field label="Password" value={settings.multilogin.password} type="password" onChange={v => updateSettings({ multilogin: { ...settings.multilogin, password: v } })} />
          <Field label="Local API URL" value={settings.multilogin.apiUrl} onChange={v => updateSettings({ multilogin: { ...settings.multilogin, apiUrl: v } })} monospace />
          <TestButton label="Test Connection" onTest={() => {}} />
        </Section>

        {/* Smartproxy */}
        <Section title="🌐 SmartProxy Config">
          <Field label="Username" value={settings.smartproxy.username} onChange={v => updateSettings({ smartproxy: { ...settings.smartproxy, username: v } })} monospace />
          <Field label="Password" value={settings.smartproxy.password} type="password" onChange={v => updateSettings({ smartproxy: { ...settings.smartproxy, password: v } })} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Host" value={settings.smartproxy.host} onChange={v => updateSettings({ smartproxy: { ...settings.smartproxy, host: v } })} monospace />
            <Field label="Port" value={settings.smartproxy.port} onChange={v => updateSettings({ smartproxy: { ...settings.smartproxy, port: Number(v) } })} />
          </div>
          <TestButton label="Test Proxy" onTest={() => {}} />
        </Section>

        {/* Roobet Config */}
        <Section title="⚡ Roobet Config">
          <Field label="Base URL" value={settings.roobet.baseUrl} onChange={v => updateSettings({ roobet: { ...settings.roobet, baseUrl: v } })} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Default Bet ($)" value={settings.roobet.defaultBet} onChange={v => updateSettings({ roobet: { ...settings.roobet, defaultBet: Number(v) } })} />
            <Field label="Default Multiplier" value={settings.roobet.defaultMultiplier} onChange={v => updateSettings({ roobet: { ...settings.roobet, defaultMultiplier: Number(v) } })} />
          </div>
          <Field label="Withdrawal Address" value={settings.roobet.withdrawalAddress} onChange={v => updateSettings({ roobet: { ...settings.roobet, withdrawalAddress: v } })} monospace />
        </Section>

        {/* Gamdom Config */}
        <Section title="🎮 Gamdom Config">
          <Field label="Base URL" value={settings.gamdom.baseUrl} onChange={v => updateSettings({ gamdom: { ...settings.gamdom, baseUrl: v } })} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Default Bet ($)" value={settings.gamdom.defaultBet} onChange={v => updateSettings({ gamdom: { ...settings.gamdom, defaultBet: Number(v) } })} />
            <Field label="Default Multiplier" value={settings.gamdom.defaultMultiplier} onChange={v => updateSettings({ gamdom: { ...settings.gamdom, defaultMultiplier: Number(v) } })} />
          </div>
        </Section>

        {/* Stake Config */}
        <Section title="🐾 Stake.pet Config">
          <Field label="Base URL" value={settings.stake.baseUrl} onChange={v => updateSettings({ stake: { ...settings.stake, baseUrl: v } })} />
          <div className="grid grid-cols-2 gap-3">
            <Field label="Default Bet ($)" value={settings.stake.defaultBet} onChange={v => updateSettings({ stake: { ...settings.stake, defaultBet: Number(v) } })} />
            <Field label="Default Multiplier" value={settings.stake.defaultMultiplier} onChange={v => updateSettings({ stake: { ...settings.stake, defaultMultiplier: Number(v) } })} />
          </div>
        </Section>

        {/* Notifications */}
        <Section title="🔔 Notifications">
          <div className="space-y-3">
            {([
              ['browser', 'Browser Notifications ON/OFF'],
              ['profitAlert', 'Alert on Profit Target hit'],
              ['lossAlert', 'Alert on Loss Limit hit'],
              ['botStop', 'Alert on Bot Stop'],
              ['banAlert', 'Alert on Account Ban'],
            ] as const).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-sm text-gray-300">{label}</span>
                <Toggle
                  value={settings.notifications[key]}
                  onChange={v => updateSettings({ notifications: { ...settings.notifications, [key]: v } })}
                />
              </div>
            ))}
          </div>
          <div className="flex items-center gap-2 px-3 py-2 bg-gray-700/30 rounded-lg opacity-60 cursor-not-allowed mt-2">
            <span className="text-lg">🔜</span>
            <span className="text-sm text-gray-400">Telegram Bot Notifications — Coming Soon</span>
          </div>
        </Section>

        {/* Seed Auto-Rotator */}
        <Section title="🌱 Seed Auto-Rotator">
          <div className="space-y-3">
            <Field label="Rotate after X bets" value={settings.seedRotator.rotateAfterBets} onChange={v => updateSettings({ seedRotator: { ...settings.seedRotator, rotateAfterBets: Number(v) } })} />
            <Field label="Rotate on X consecutive losses" value={settings.seedRotator.rotateOnConsecutiveLosses} onChange={v => updateSettings({ seedRotator: { ...settings.seedRotator, rotateOnConsecutiveLosses: Number(v) } })} />
            <Field label="Rotate on X consecutive wins" value={settings.seedRotator.rotateOnConsecutiveWins} onChange={v => updateSettings({ seedRotator: { ...settings.seedRotator, rotateOnConsecutiveWins: Number(v) } })} />
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Never reuse seed</span>
              <Toggle
                value={settings.seedRotator.neverReuse}
                onChange={v => updateSettings({ seedRotator: { ...settings.seedRotator, neverReuse: v } })}
              />
            </div>
          </div>
        </Section>

        {/* Health Monitor */}
        <Section title="❤️ Account Health Monitor">
          <Field label="Check every X minutes" value={settings.healthMonitor.checkEveryMinutes} onChange={v => updateSettings({ healthMonitor: { ...settings.healthMonitor, checkEveryMinutes: Number(v) } })} />
          <div className="space-y-3">
            {([
              ['alertOnBan', 'Alert on ban detect'],
              ['alertOnSessionExpire', 'Alert on session expire'],
              ['autoRelogin', 'Auto re-login ON/OFF'],
            ] as const).map(([key, label]) => (
              <div key={key} className="flex items-center justify-between">
                <span className="text-sm text-gray-300">{label}</span>
                <Toggle
                  value={settings.healthMonitor[key]}
                  onChange={v => updateSettings({ healthMonitor: { ...settings.healthMonitor, [key]: v } })}
                />
              </div>
            ))}
          </div>
        </Section>

        {/* Session Token Extractor */}
        <Section title="🔑 Session Token Extractor">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Auto-extract on browser open</span>
              <Toggle value={true} onChange={() => {}} />
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-300">Manual paste fallback</span>
              <Toggle value={true} onChange={() => {}} />
            </div>
          </div>
          <div className="mt-2 p-3 bg-gray-700/30 rounded-lg">
            <div className="text-xs text-gray-400 mb-1">Manual Token Paste</div>
            <div className="flex gap-2">
              <input placeholder="Paste session token here..." className="flex-1 px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-xs text-white outline-none focus:border-yellow-500/50 font-mono" />
              <button className="px-3 py-2 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-semibold rounded-lg">Apply</button>
            </div>
          </div>
        </Section>
      </div>

      {/* Coming Soon */}
      <div className="bg-gray-800/30 border border-gray-700/30 rounded-xl p-5">
        <h3 className="font-semibold text-gray-500 text-sm mb-4">🔜 Coming Soon (Disabled)</h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 opacity-60">
          {[
            { icon: '🤖', title: '2Captcha Auto-Solve', desc: 'Automatic CAPTCHA solving integration' },
            { icon: '📬', title: 'IMAP Auto-OTP', desc: 'Automatic email OTP extraction via IMAP' },
            { icon: '📱', title: 'Telegram Notifications', desc: 'Bot alerts via Telegram message' },
          ].map(item => (
            <div key={item.title} className="bg-gray-800/50 rounded-xl p-4 cursor-not-allowed border border-gray-700/30">
              <div className="text-2xl mb-2">{item.icon}</div>
              <div className="font-medium text-gray-400 text-sm">{item.title}</div>
              <div className="text-xs text-gray-600 mt-1">{item.desc}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
