import { useState } from 'react';
import { useStore } from '../store';
import { CheckCircle, Globe } from 'lucide-react';

export default function EmailOTP() {
  const { emailOTPs, updateEmailOTP, accounts } = useStore();
  const [filter, setFilter] = useState<'all' | 'Pending' | 'Verified'>('Pending');

  const filtered = emailOTPs.filter(o => filter === 'all' || o.status === filter);

  const handleVerify = (id: string, otp: string) => {
    if (!otp || otp.length < 4) return;
    updateEmailOTP(id, { status: 'Verified' });
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Email / OTP Verification</h1>
          <p className="text-gray-400 text-sm mt-1">Verify registered accounts via OTP</p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex gap-2">
        {(['all', 'Pending', 'Verified'] as const).map(f => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border ${filter === f ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}
          >
            {f} {f === 'Pending' && `(${emailOTPs.filter(o => o.status === 'Pending').length})`}
          </button>
        ))}
      </div>

      <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-gray-700/50 bg-gray-900/30">
              {['#', 'Email', 'Site', 'Account', 'Status', 'OTP Input', 'Actions'].map(h => (
                <th key={h} className="text-left px-4 py-3 text-gray-400 font-medium">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.map((otp, i) => (
              <tr key={otp.id} className="border-b border-gray-700/30 hover:bg-gray-700/20">
                <td className="px-4 py-3 text-gray-500">{i + 1}</td>
                <td className="px-4 py-3 text-gray-200 font-mono text-[11px]">{otp.email}</td>
                <td className="px-4 py-3 text-yellow-400">{otp.site}</td>
                <td className="px-4 py-3 text-gray-400">{accounts.find(a => a.id === otp.accountId)?.username || '—'}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${otp.status === 'Verified' ? 'bg-green-500/20 text-green-400 border-green-500/40' : 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40'}`}>
                    {otp.status}
                  </span>
                </td>
                <td className="px-4 py-3">
                  {otp.status === 'Pending' && (
                    <input
                      value={otp.otp}
                      onChange={e => updateEmailOTP(otp.id, { otp: e.target.value })}
                      placeholder="Enter OTP..."
                      className="w-32 bg-gray-700/50 border border-gray-600/50 rounded px-2 py-1 text-gray-200 outline-none focus:border-yellow-500/50 font-mono tracking-widest"
                      maxLength={8}
                    />
                  )}
                  {otp.status === 'Verified' && (
                    <span className="text-green-400 flex items-center gap-1"><CheckCircle className="w-3.5 h-3.5" /> Verified</span>
                  )}
                </td>
                <td className="px-4 py-3">
                  <div className="flex gap-2">
                    <button className="flex items-center gap-1 px-2.5 py-1 bg-gray-700/50 hover:bg-gray-700 text-gray-300 text-[10px] rounded border border-gray-600/50 transition-colors">
                      <Globe className="w-3 h-3" /> Open Email
                    </button>
                    {otp.status === 'Pending' && (
                      <button
                        onClick={() => handleVerify(otp.id, otp.otp)}
                        disabled={!otp.otp || otp.otp.length < 4}
                        className="px-2.5 py-1 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-[10px] rounded border border-green-500/30 transition-colors disabled:opacity-40"
                      >
                        Submit OTP
                      </button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
            {filtered.length === 0 && (
              <tr>
                <td colSpan={7} className="text-center py-8 text-gray-500 text-sm">
                  {filter === 'Pending' ? 'No pending OTP verifications' : 'No records found'}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Auto OTP notice */}
      <div className="flex items-center gap-2 px-4 py-3 bg-gray-800/30 border border-gray-700/30 rounded-xl opacity-60 cursor-not-allowed">
        <span className="text-lg">🔜</span>
        <div>
          <span className="text-sm text-gray-400 font-medium">IMAP / Gmail API Auto-OTP</span>
          <span className="text-xs text-gray-600 ml-2">Coming Soon</span>
        </div>
      </div>
    </div>
  );
}
