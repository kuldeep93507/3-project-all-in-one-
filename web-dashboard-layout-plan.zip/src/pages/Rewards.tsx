import { useState } from 'react';
import { Gift, Clock, CheckCircle, ToggleLeft, ToggleRight } from 'lucide-react';
import { useStore, Site } from '../store';
import { v4 as uuidv4 } from 'uuid';

type RewardType = 'Vault' | 'Rakeback' | 'Daily' | 'Weekly' | 'Monthly';

const rewardTypes: RewardType[] = ['Vault', 'Rakeback', 'Daily', 'Weekly', 'Monthly'];

const rewardEmojis: Record<RewardType, string> = {
  Vault: '🏦',
  Rakeback: '💰',
  Daily: '📅',
  Weekly: '📆',
  Monthly: '🗓️',
};

const mockRewardData = (_profileId: string) => ({
  Vault: (Math.random() * 5).toFixed(2),
  Rakeback: (Math.random() * 2).toFixed(2),
  Daily: (Math.random() * 1).toFixed(2),
  Weekly: (Math.random() * 3).toFixed(2),
  Monthly: (Math.random() * 10).toFixed(2),
});

export default function Rewards() {
  const { activeSite, profiles, rewardClaims, addRewardClaim, rewardSettings, updateRewardSettings } = useStore();
  const [selectedSite, setSelectedSite] = useState<Site>(activeSite);
  const [selected, setSelected] = useState<string[]>([]);
  const [showHistory, setShowHistory] = useState(false);
  const [claimingMap, setClaimingMap] = useState<Record<string, boolean>>({});

  const siteProfiles = profiles.filter(p => p.site === selectedSite);
  const [rewardData] = useState(() => {
    const data: Record<string, Record<RewardType, string>> = {};
    siteProfiles.forEach(p => { data[p.id] = mockRewardData(p.id); });
    return data;
  });

  const toggleSelect = (id: string) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const toggleAll = () => setSelected(selected.length === siteProfiles.length ? [] : siteProfiles.map(p => p.id));

  const handleClaim = (profileId: string, type: RewardType) => {
    const key = `${profileId}-${type}`;
    setClaimingMap(m => ({ ...m, [key]: true }));
    setTimeout(() => {
      const amount = parseFloat(rewardData[profileId]?.[type] || '0');
      addRewardClaim({
        id: uuidv4(),
        profileId,
        site: selectedSite,
        type,
        amount,
        time: new Date().toLocaleString(),
        status: 'Claimed',
      });
      setClaimingMap(m => ({ ...m, [key]: false }));
    }, 1500);
  };

  const handleClaimAll = (type?: RewardType) => {
    const targets = selected.length > 0 ? selected : siteProfiles.map(p => p.id);
    const types = type ? [type] : rewardTypes;
    targets.forEach(profileId => {
      types.forEach(t => handleClaim(profileId, t));
    });
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Rewards</h1>
          <p className="text-gray-400 text-sm mt-1">Claim vault, rakeback, daily, weekly, monthly rewards</p>
        </div>
        <button onClick={() => setShowHistory(!showHistory)} className={`px-4 py-2 text-xs rounded-xl border transition-colors ${showHistory ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>
          {showHistory ? 'Show Claims' : 'Claim History'}
        </button>
      </div>

      {/* Site Selector */}
      <div className="flex gap-2">
        {(['roobet.party', 'gamdom.win', 'stake.pet'] as Site[]).map(site => (
          <button key={site} onClick={() => setSelectedSite(site)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border ${selectedSite === site ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>
            {site}
          </button>
        ))}
      </div>

      {!showHistory ? (
        <>
          {/* Bulk Actions */}
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3 flex-wrap">
              <input type="checkbox" checked={selected.length === siteProfiles.length} onChange={toggleAll} className="accent-yellow-500" />
              <span className="text-xs text-gray-400">{selected.length > 0 ? `${selected.length} selected` : 'Select All'}</span>
              <div className="ml-auto flex flex-wrap gap-2">
                <button onClick={() => handleClaimAll()} className="flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 text-xs rounded-lg border border-yellow-500/30 transition-colors">
                  <Gift className="w-3.5 h-3.5" /> Claim All Rewards
                </button>
                {rewardTypes.map(type => (
                  <button key={type} onClick={() => handleClaimAll(type)} className="flex items-center gap-1 px-2.5 py-1.5 bg-gray-700/50 hover:bg-gray-700 text-gray-300 text-[10px] rounded-lg border border-gray-600/50 transition-colors">
                    {rewardEmojis[type]} {type} Only
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Profile Rewards Table */}
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-gray-700/50 bg-gray-900/30">
                    <th className="text-left px-3 py-3 text-gray-400 font-medium w-8"><input type="checkbox" checked={selected.length === siteProfiles.length} onChange={toggleAll} className="accent-yellow-500" /></th>
                    <th className="text-left px-3 py-3 text-gray-400 font-medium">Profile</th>
                    <th className="text-left px-3 py-3 text-gray-400 font-medium">Account</th>
                    {rewardTypes.map(t => (
                      <th key={t} className="text-center px-3 py-3 text-gray-400 font-medium">{rewardEmojis[t]} {t}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {siteProfiles.map(profile => {
                    const data = rewardData[profile.id] || {};
                    return (
                      <tr key={profile.id} className="border-b border-gray-700/30 hover:bg-gray-700/20">
                        <td className="px-3 py-3">
                          <input type="checkbox" checked={selected.includes(profile.id)} onChange={() => toggleSelect(profile.id)} className="accent-yellow-500" />
                        </td>
                        <td className="px-3 py-3 text-gray-200 font-medium">{profile.name}</td>
                        <td className="px-3 py-3 text-gray-400">{profile.accountId || '—'}</td>
                        {rewardTypes.map(type => {
                          const key = `${profile.id}-${type}`;
                          const claiming = claimingMap[key];
                          return (
                            <td key={type} className="px-3 py-3 text-center">
                              <div className="flex flex-col items-center gap-1">
                                <span className="text-green-400 font-mono font-semibold">${data[type] || '0.00'}</span>
                                <button
                                  onClick={() => handleClaim(profile.id, type)}
                                  disabled={claiming}
                                  className={`px-2 py-0.5 text-[10px] rounded border transition-colors ${claiming ? 'bg-gray-700/50 text-gray-500 border-gray-600/30' : 'bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border-yellow-500/30'}`}
                                >
                                  {claiming ? (
                                    <span className="flex items-center gap-1"><div className="w-2 h-2 border border-yellow-400 border-t-transparent rounded-full animate-spin" />Claiming</span>
                                  ) : 'Claim'}
                                </button>
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    );
                  })}
                  {siteProfiles.length === 0 && (
                    <tr><td colSpan={7} className="text-center py-8 text-gray-500">No profiles for {selectedSite}</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

          {/* Auto-Scheduler */}
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
            <h3 className="font-semibold text-white mb-4 flex items-center gap-2"><Clock className="w-4 h-4" /> Auto-Scheduler</h3>
            <div className="space-y-3">
              {[
                { key: 'vault', label: '🏦 Vault', desc: `Auto-claim when $${rewardSettings.vault.threshold} reached`, hasThreshold: true },
                { key: 'rakeback', label: '💰 Rakeback', desc: `Every ${rewardSettings.rakeback.everyHours}h`, hasHours: true },
                { key: 'daily', label: '📅 Daily', desc: 'Midnight auto-claim' },
                { key: 'weekly', label: '📆 Weekly', desc: 'Monday 00:00 auto-claim' },
                { key: 'monthly', label: '🗓️ Monthly', desc: '1st of month 00:00 auto-claim' },
              ].map(item => {
                const enabled = rewardSettings[item.key as keyof typeof rewardSettings] as any;
                return (
                  <div key={item.key} className="flex items-center gap-3 bg-gray-700/30 rounded-xl px-3 py-2.5">
                    <button onClick={() => updateRewardSettings({ [item.key]: { ...enabled, enabled: !enabled.enabled } })}>
                      {enabled.enabled ? <ToggleRight className="w-6 h-6 text-green-400" /> : <ToggleLeft className="w-6 h-6 text-gray-500" />}
                    </button>
                    <div className="flex-1">
                      <div className="text-sm text-gray-200">{item.label}</div>
                      <div className="text-xs text-gray-500">{item.desc}</div>
                    </div>
                    {item.hasThreshold && (
                      <div className="flex items-center gap-1">
                        <span className="text-[10px] text-gray-500">$</span>
                        <input type="number" value={rewardSettings.vault.threshold} onChange={e => updateRewardSettings({ vault: { ...rewardSettings.vault, threshold: Number(e.target.value) } })} className="w-16 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-xs text-white outline-none" />
                      </div>
                    )}
                    {item.hasHours && (
                      <div className="flex items-center gap-1">
                        <input type="number" value={rewardSettings.rakeback.everyHours} onChange={e => updateRewardSettings({ rakeback: { ...rewardSettings.rakeback, everyHours: Number(e.target.value) } })} className="w-16 px-2 py-1 bg-gray-700 border border-gray-600 rounded text-xs text-white outline-none" />
                        <span className="text-[10px] text-gray-500">h</span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        </>
      ) : (
        /* History */
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
          <div className="px-4 py-3 border-b border-gray-700/50">
            <span className="font-semibold text-white">Claim History</span>
          </div>
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-gray-700/50 bg-gray-900/30">
                {['Profile', 'Site', 'Type', 'Amount', 'Time', 'Status'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-gray-400 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rewardClaims.map(claim => (
                <tr key={claim.id} className="border-b border-gray-700/30 hover:bg-gray-700/20">
                  <td className="px-4 py-3 text-gray-200">{claim.profileId}</td>
                  <td className="px-4 py-3 text-yellow-400">{claim.site}</td>
                  <td className="px-4 py-3 text-gray-300">{rewardEmojis[claim.type]} {claim.type}</td>
                  <td className="px-4 py-3 text-green-400 font-mono font-semibold">+${claim.amount.toFixed(2)}</td>
                  <td className="px-4 py-3 text-gray-500">{claim.time}</td>
                  <td className="px-4 py-3">
                    <span className={`flex items-center gap-1 ${claim.status === 'Claimed' ? 'text-green-400' : claim.status === 'Failed' ? 'text-red-400' : 'text-yellow-400'}`}>
                      {claim.status === 'Claimed' && <CheckCircle className="w-3 h-3" />}
                      {claim.status}
                    </span>
                  </td>
                </tr>
              ))}
              {rewardClaims.length === 0 && (
                <tr><td colSpan={6} className="text-center py-8 text-gray-500">No claim history yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
