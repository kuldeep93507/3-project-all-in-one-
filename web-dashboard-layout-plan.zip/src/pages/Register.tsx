import { useState } from 'react';
import { Plus, Trash2, Play, Upload } from 'lucide-react';
import { useStore, RegisterAccount, Site } from '../store';
import { v4 as uuidv4 } from 'uuid';

const statusColors: Record<RegisterAccount['status'], string> = {
  'Pending': 'bg-gray-500/20 text-gray-400 border-gray-500/40',
  'Registering': 'bg-blue-500/20 text-blue-400 border-blue-500/40',
  'Email Pending': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
  'Done': 'bg-green-500/20 text-green-400 border-green-500/40',
  'Failed': 'bg-red-500/20 text-red-400 border-red-500/40',
};

export default function Register() {
  const { registerAccounts, addRegisterAccount, updateRegisterAccount, removeRegisterAccount, addAccount, addEmailOTP, activeSite } = useStore();
  const [selectedSite, setSelectedSite] = useState<Site>(activeSite);

  const filtered = registerAccounts.filter(a => a.site === selectedSite);

  const handleAddRow = () => {
    addRegisterAccount({
      id: uuidv4(),
      email: '',
      username: '',
      password: '',
      site: selectedSite,
      status: 'Pending',
    });
  };

  const simulateRegister = (acc: RegisterAccount) => {
    updateRegisterAccount(acc.id, { status: 'Registering' });
    setTimeout(() => {
      updateRegisterAccount(acc.id, { status: 'Email Pending' });
      addEmailOTP({ id: uuidv4(), email: acc.email, site: acc.site, accountId: acc.id, status: 'Pending', otp: '' });
    }, 2000);
  };

  const simulateDone = (acc: RegisterAccount) => {
    updateRegisterAccount(acc.id, { status: 'Done' });
    addAccount({
      id: uuidv4(),
      site: acc.site,
      email: acc.email,
      username: acc.username,
      password: acc.password,
      balance: 0,
      status: 'Unverified',
      profileId: '',
      createdOn: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString().split('T')[0],
      totalProfit: 0,
      totalBets: 0,
      totalWins: 0,
    });
  };

  const registerSteps: Record<Site, string[]> = {
    'roobet.party': [
      '1. Select Profile (or auto-create Multilogin profile)',
      '2. Click "Register" → browser opens → roobet.party/register',
      '3. Auto-fill: Email, Username, Password',
      '4. Form submit → Status: "Email Verify Pending"',
      '5. Go to Email Page → OTP verify',
      '6. Status: "Done ✓" → Account saved permanently',
    ],
    'gamdom.win': [
      '1. Select Profile',
      '2. Click "Register" → browser opens → gamdom.win',
      '3. Click [data-testid="signup-nav"] (Create Account)',
      '4. Auto-fill: Username, Email, Password in modal',
      '5. Tick Terms checkbox → "Start Playing" click',
      '6. Status: "Email Verify Pending"',
      '7. Email Page → OTP → Done ✓ → Save permanent',
    ],
    'stake.pet': [
      '1. Select Profile (Multilogin REQUIRED)',
      '2. Click "Register" → browser opens → stake.pet/register',
      '3. Auto-fill: Email, Username, Password',
      '4. Submit → Email verify',
      '5. Done ✓ → Save permanent',
    ],
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Register Accounts</h1>
          <p className="text-gray-400 text-sm mt-1">Bulk register accounts on all 3 sites</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-2 px-3 py-2 text-xs bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg border border-gray-600 transition-colors">
            <Upload className="w-3.5 h-3.5" /> Import CSV
          </button>
        </div>
      </div>

      {/* Site Selector */}
      <div className="flex gap-2">
        {(['roobet.party', 'gamdom.win', 'stake.pet'] as Site[]).map(site => (
          <button
            key={site}
            onClick={() => setSelectedSite(site)}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border ${selectedSite === site ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}
          >
            {site}
          </button>
        ))}
      </div>

      {/* Register Process Info */}
      <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
        <h3 className="font-semibold text-white mb-3 text-sm">📋 Register Process — {selectedSite}</h3>
        <div className="space-y-1">
          {registerSteps[selectedSite].map((step, i) => (
            <div key={i} className="text-xs text-gray-400 flex items-start gap-2">
              <div className="w-1.5 h-1.5 rounded-full bg-yellow-500/60 mt-1 shrink-0" />
              {step}
            </div>
          ))}
        </div>
      </div>

      {/* Account Pool Table */}
      <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-700/50">
          <span className="font-semibold text-white text-sm">Account Pool — {selectedSite}</span>
          <div className="flex gap-2">
            <button
              onClick={() => filtered.filter(a => a.status === 'Pending' && a.email && a.username && a.password).forEach(a => simulateRegister(a))}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-xs rounded-lg border border-green-500/30 transition-colors"
            >
              <Play className="w-3 h-3" /> Register All Pending
            </button>
            <button onClick={handleAddRow} className="flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-semibold rounded-lg">
              <Plus className="w-3 h-3" /> Add Row
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-gray-700/50 bg-gray-900/30">
                {['#', 'Email', 'Username', 'Password', 'Site', 'Status', 'Actions'].map(h => (
                  <th key={h} className="text-left px-3 py-2.5 text-gray-400 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((acc, i) => (
                <tr key={acc.id} className="border-b border-gray-700/30 hover:bg-gray-700/20">
                  <td className="px-3 py-2.5 text-gray-500">{i + 1}</td>
                  <td className="px-3 py-2.5">
                    <input
                      value={acc.email}
                      onChange={e => updateRegisterAccount(acc.id, { email: e.target.value })}
                      placeholder="email@example.com"
                      className="w-full bg-transparent border border-gray-700/50 rounded px-2 py-1 text-gray-200 outline-none focus:border-yellow-500/50 font-mono text-[11px]"
                    />
                  </td>
                  <td className="px-3 py-2.5">
                    <input
                      value={acc.username}
                      onChange={e => updateRegisterAccount(acc.id, { username: e.target.value })}
                      placeholder="username"
                      className="w-full bg-transparent border border-gray-700/50 rounded px-2 py-1 text-gray-200 outline-none focus:border-yellow-500/50"
                    />
                  </td>
                  <td className="px-3 py-2.5">
                    <input
                      value={acc.password}
                      onChange={e => updateRegisterAccount(acc.id, { password: e.target.value })}
                      placeholder="password"
                      type="password"
                      className="w-full bg-transparent border border-gray-700/50 rounded px-2 py-1 text-gray-200 outline-none focus:border-yellow-500/50"
                    />
                  </td>
                  <td className="px-3 py-2.5">
                    <select value={acc.site} onChange={e => updateRegisterAccount(acc.id, { site: e.target.value as Site })} className="bg-gray-700/50 border border-gray-600/50 rounded px-2 py-1 text-gray-300 outline-none text-[11px]">
                      <option value="roobet.party">roobet.party</option>
                      <option value="gamdom.win">gamdom.win</option>
                      <option value="stake.pet">stake.pet</option>
                    </select>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex items-center gap-1.5">
                      {acc.status === 'Registering' && <div className="w-2 h-2 border border-blue-400 border-t-transparent rounded-full animate-spin" />}
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${statusColors[acc.status]}`}>{acc.status}</span>
                    </div>
                  </td>
                  <td className="px-3 py-2.5">
                    <div className="flex gap-1">
                      {acc.status === 'Pending' && (
                        <button onClick={() => simulateRegister(acc)} disabled={!acc.email || !acc.username || !acc.password} className="px-2.5 py-1 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-[10px] rounded border border-green-500/30 transition-colors disabled:opacity-40">
                          Register
                        </button>
                      )}
                      {acc.status === 'Email Pending' && (
                        <button onClick={() => simulateDone(acc)} className="px-2.5 py-1 bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 text-[10px] rounded border border-yellow-500/30 transition-colors">
                          Verify OTP →
                        </button>
                      )}
                      {acc.status !== 'Done' && (
                        <button onClick={() => removeRegisterAccount(acc.id)} className="p-1 text-gray-500 hover:text-red-400 transition-colors">
                          <Trash2 className="w-3 h-3" />
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filtered.length === 0 && (
            <div className="text-center py-8 text-gray-500 text-sm">No accounts in pool. Click "+ Add Row" to add.</div>
          )}
        </div>
      </div>

      {/* Captcha notice */}
      <div className="flex items-center gap-2 px-4 py-3 bg-gray-800/30 border border-gray-700/30 rounded-xl opacity-60 cursor-not-allowed">
        <span className="text-lg">🔜</span>
        <div>
          <span className="text-sm text-gray-400 font-medium">2Captcha Auto-Solve</span>
          <span className="text-xs text-gray-600 ml-2">Coming Soon</span>
        </div>
      </div>
    </div>
  );
}
