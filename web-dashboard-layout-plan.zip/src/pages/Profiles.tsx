import { useState } from 'react';
import { Play, Square, RefreshCw, DollarSign, Trash2, Globe, Plus, X, AlertTriangle, Check } from 'lucide-react';
import { useStore, Profile, Site } from '../store';
import { v4 as uuidv4 } from 'uuid';

const botStatusColors = {
  Running: 'bg-green-500/20 text-green-400 border-green-500/40',
  Stopped: 'bg-gray-500/20 text-gray-400 border-gray-500/40',
  Error: 'bg-red-500/20 text-red-400 border-red-500/40',
};

const siteColors: Record<Site, string> = {
  'roobet.party': 'text-yellow-400',
  'gamdom.win': 'text-green-400',
  'stake.pet': 'text-blue-400',
};

const games: Record<Site, string[]> = {
  'roobet.party': ['Limbo', 'Dice', 'Mines', 'Roulette', 'Baccarat'],
  'gamdom.win': ['Limbo', 'Dice', 'Mines', 'Crash', 'Roulette', 'Blackjack', 'Plinko', 'Keno', 'HiLo', 'Pocket Dice', 'Twist'],
  'stake.pet': ['Limbo', 'Dice', 'Mines', 'Crash', 'Plinko', 'Keno', 'HiLo', 'Wheel', 'Dragon Tower', 'Chicken', 'Flip', 'Pump'],
};

function SeedDuplicateAlert({ profiles }: { profiles: Profile[] }) {
  const hashCounts: Record<string, string[]> = {};
  profiles.forEach(p => {
    if (!hashCounts[p.serverHash]) hashCounts[p.serverHash] = [];
    hashCounts[p.serverHash].push(p.name);
  });
  const duplicates = Object.entries(hashCounts).filter(([, names]) => names.length > 1);
  if (duplicates.length === 0) return null;
  return (
    <div className="bg-red-500/10 border border-red-500/40 rounded-xl p-3 space-y-1">
      {duplicates.map(([hash, names]) => (
        <div key={hash} className="flex items-center gap-2 text-xs text-red-400">
          <AlertTriangle className="w-4 h-4 shrink-0" />
          <span>⚠️ {names.join(' & ')} ka Server Hash same hai! ({hash.slice(0, 8)}...)</span>
        </div>
      ))}
    </div>
  );
}

function StartBotModal({ profile, onClose }: { profile: Profile; onClose: () => void }) {
  const { startBot, updateProfile, betSettings } = useStore();
  const [game, setGame] = useState(profile.activeGame || games[profile.site][0]);
  const [betAmt, setBetAmt] = useState(betSettings.betAmount);
  const [targetMult, setTargetMult] = useState(profile.site === 'roobet.party' ? 1.01 : 2.00);
  const [strategy, setStrategy] = useState<string>('Martingale');
  const [martMult, setMartMult] = useState(2);
  const [martSteps, setMartSteps] = useState(6);
  const [stopProfit, setStopProfit] = useState(10);
  const [stopLoss, setStopLoss] = useState(5);
  const [maxBets, setMaxBets] = useState(0);

  const handleStart = () => {
    updateProfile(profile.id, { activeGame: game });
    startBot(profile.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
      <div className="bg-gray-800 border border-gray-600 rounded-2xl p-6 w-[480px] shadow-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-5">
          <h3 className="font-bold text-white">Start Bot — {profile.name}</h3>
          <button onClick={onClose} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
        </div>
        <div className="space-y-4">
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Game</label>
            <select value={game} onChange={e => setGame(e.target.value)} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none">
              {games[profile.site].map(g => <option key={g} value={g}>{g}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Bet Amount ($)</label>
              <input type="number" value={betAmt} onChange={e => setBetAmt(Number(e.target.value))} step="0.01" min="0.01" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Target Multiplier</label>
              <input type="number" value={targetMult} onChange={e => setTargetMult(Number(e.target.value))} step="0.01" min="1.01" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
            </div>
          </div>
          <div>
            <label className="text-xs text-gray-400 mb-1.5 block">Strategy</label>
            <select value={strategy} onChange={e => setStrategy(e.target.value)} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none">
              {['OFF', 'Martingale', 'Anti-Martingale', "D'Alembert", 'Fibonacci'].map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          {strategy === 'Martingale' && (
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Martingale Multiplier</label>
                <input type="number" value={martMult} onChange={e => setMartMult(Number(e.target.value))} step="0.5" min="1.5" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1.5 block">Max Steps</label>
                <input type="number" value={martSteps} onChange={e => setMartSteps(Number(e.target.value))} min="1" max="20" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
              </div>
            </div>
          )}
          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Stop Profit ($)</label>
              <input type="number" value={stopProfit} onChange={e => setStopProfit(Number(e.target.value))} min="0" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Stop Loss ($)</label>
              <input type="number" value={stopLoss} onChange={e => setStopLoss(Number(e.target.value))} min="0" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1.5 block">Max Bets (0=∞)</label>
              <input type="number" value={maxBets} onChange={e => setMaxBets(Number(e.target.value))} min="0" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
            </div>
          </div>
        </div>
        <button onClick={handleStart} className="w-full mt-5 py-3 bg-green-500 hover:bg-green-400 text-black font-bold rounded-xl transition-colors flex items-center justify-center gap-2">
          <Play className="w-4 h-4" /> Start Bot
        </button>
      </div>
    </div>
  );
}

export default function Profiles() {
  const { profiles, accounts, profileMode, setProfileMode, multiloginConnected, setMultiloginConnected, startBot, stopBot, rotateSeeds, removeProfile, updateProfile, addProfile } = useStore();
  const [selected, setSelected] = useState<string[]>([]);
  const [startBotProfile, setStartBotProfile] = useState<Profile | null>(null);
  const [search, setSearch] = useState('');
  const [directSession, setDirectSession] = useState({ token: '', site: 'roobet.party' as Site, game: 'Limbo', betAmt: 0.01 });
  const { activeSite } = useStore();

  const filteredProfiles = profiles.filter(p =>
    p.site === activeSite &&
    (search === '' || p.name.toLowerCase().includes(search.toLowerCase()))
  );

  const toggleSelect = (id: string) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const generateHash = () => Math.random().toString(36).substring(2, 12) + Math.random().toString(36).substring(2, 12);
  const generateSeed = () => Math.random().toString(36).substring(2, 10).toUpperCase() + Math.random().toString(36).substring(2, 10);

  const handleNewProfile = () => {
    addProfile({
      id: uuidv4(),
      name: `Profile ${profiles.length + 1}`,
      accountId: accounts[0]?.id || '',
      site: activeSite,
      balance: 0,
      activeGame: '',
      botStatus: 'Stopped',
      serverHash: generateHash(),
      clientSeed: generateSeed(),
      cdpPort: 9222 + profiles.length,
      sessionToken: '',
      profit: 0,
      bets: 0,
      wins: 0,
    });
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      {/* Mode Selector */}
      <div className="grid grid-cols-2 gap-4">
        <button
          onClick={() => setProfileMode('multilogin')}
          className={`p-4 rounded-xl border-2 text-left transition-all ${profileMode === 'multilogin' ? 'border-yellow-500/60 bg-yellow-500/10' : 'border-gray-700 bg-gray-800/50 hover:border-gray-600'}`}
        >
          <div className="text-2xl mb-1">🦊</div>
          <div className="font-bold text-white text-sm">Multilogin X</div>
          <div className="text-xs text-gray-400 mt-0.5">Antidetect browser • Fingerprint protection</div>
          {profileMode === 'multilogin' && <div className="mt-2 text-xs text-yellow-400 font-semibold">[PRO] SELECTED</div>}
        </button>
        <button
          onClick={() => setProfileMode('direct')}
          className={`p-4 rounded-xl border-2 text-left transition-all ${profileMode === 'direct' ? 'border-blue-500/60 bg-blue-500/10' : 'border-gray-700 bg-gray-800/50 hover:border-gray-600'}`}
        >
          <div className="text-2xl mb-1">🌐</div>
          <div className="font-bold text-white text-sm">Direct Chrome</div>
          <div className="text-xs text-gray-400 mt-0.5">Session token paste • No Multilogin needed</div>
          {profileMode === 'direct' && <div className="mt-2 text-xs text-blue-400 font-semibold">[FREE] SELECTED</div>}
        </button>
      </div>

      {/* Direct Chrome Mode */}
      {profileMode === 'direct' && (
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-5 space-y-4">
          <h3 className="font-semibold text-white">🌐 Direct Chrome Mode</h3>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Session Token</label>
              <input value={directSession.token} onChange={e => setDirectSession(p => ({ ...p, token: e.target.value }))} placeholder="inersc2a2k..." className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none font-mono" />
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Site</label>
              <select value={directSession.site} onChange={e => setDirectSession(p => ({ ...p, site: e.target.value as Site }))} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none">
                <option value="roobet.party">roobet.party</option>
                <option value="gamdom.win">gamdom.win</option>
                <option value="stake.pet">stake.pet</option>
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Game</label>
              <select value={directSession.game} onChange={e => setDirectSession(p => ({ ...p, game: e.target.value }))} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none">
                {games[directSession.site].map(g => <option key={g} value={g}>{g}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-gray-400 mb-1 block">Bet Amount ($)</label>
              <input type="number" value={directSession.betAmt} onChange={e => setDirectSession(p => ({ ...p, betAmt: Number(e.target.value) }))} step="0.01" min="0.01" className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none" />
            </div>
          </div>
          <div className="flex gap-2">
            <button className="px-4 py-2 bg-gray-600 hover:bg-gray-500 text-white text-sm rounded-lg transition-colors">Check Balance</button>
            <button className="px-4 py-2 bg-green-500 hover:bg-green-400 text-black font-bold text-sm rounded-lg transition-colors flex items-center gap-2">
              🚀 Launch Bot
            </button>
          </div>
        </div>
      )}

      {/* Multilogin Mode */}
      {profileMode === 'multilogin' && (
        <>
          {/* Connection Status */}
          <div className={`flex items-center gap-3 px-4 py-2.5 rounded-xl border ${multiloginConnected ? 'bg-green-500/10 border-green-500/30' : 'bg-red-500/10 border-red-500/30'}`}>
            <div className={`w-2.5 h-2.5 rounded-full ${multiloginConnected ? 'bg-green-400 animate-pulse' : 'bg-red-400'}`} />
            <span className={`text-sm font-medium ${multiloginConnected ? 'text-green-400' : 'text-red-400'}`}>
              {multiloginConnected ? '🟢 Connected to Multilogin X' : '🔴 Connection Failed'}
            </span>
            <span className="text-xs text-gray-500">http://localhost:35000</span>
            {!multiloginConnected && (
              <button onClick={() => setMultiloginConnected(true)} className="ml-auto px-3 py-1 text-xs bg-gray-700 hover:bg-gray-600 text-white rounded-lg">Reconnect</button>
            )}
          </div>

          <SeedDuplicateAlert profiles={filteredProfiles} />

          {/* Toolbar */}
          <div className="flex gap-2 flex-wrap">
            <button onClick={handleNewProfile} className="flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-semibold rounded-lg">
              <Plus className="w-3.5 h-3.5" /> New Profile
            </button>
            <button onClick={() => setSelected(filteredProfiles.map(p => p.id))} className="flex items-center gap-1.5 px-3 py-1.5 bg-gray-700 hover:bg-gray-600 text-gray-300 text-xs rounded-lg">
              <Check className="w-3.5 h-3.5" /> Select All
            </button>
            <button onClick={() => selected.forEach(id => startBot(id))} disabled={selected.length === 0} className="flex items-center gap-1.5 px-3 py-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-xs rounded-lg border border-green-500/30 disabled:opacity-40">
              <Play className="w-3.5 h-3.5" /> Start Selected
            </button>
            <button onClick={() => selected.forEach(id => stopBot(id))} disabled={selected.length === 0} className="flex items-center gap-1.5 px-3 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs rounded-lg border border-red-500/30 disabled:opacity-40">
              <Square className="w-3.5 h-3.5" /> Stop Selected
            </button>
            <button onClick={() => rotateSeeds(selected.length > 0 ? selected : filteredProfiles.map(p => p.id))} className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-500/20 hover:bg-purple-500/30 text-purple-400 text-xs rounded-lg border border-purple-500/30">
              <RefreshCw className="w-3.5 h-3.5" /> Rotate Seeds
            </button>
            <div className="ml-auto">
              <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search profiles..." className="px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-gray-200 outline-none w-44" />
            </div>
          </div>

          {/* Profile Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {filteredProfiles.map(profile => {
              const account = accounts.find(a => a.id === profile.accountId);
              const isSelected = selected.includes(profile.id);
              const hashDups = filteredProfiles.filter(p => p.serverHash === profile.serverHash && p.id !== profile.id);
              return (
                <div key={profile.id} className={`bg-gray-800/50 border rounded-xl p-4 transition-all ${isSelected ? 'border-yellow-500/60 shadow-lg shadow-yellow-500/10' : 'border-gray-700/50'} ${hashDups.length > 0 ? 'border-red-500/60' : ''}`}>
                  {/* Header */}
                  <div className="flex items-center gap-2 mb-3">
                    <input type="checkbox" checked={isSelected} onChange={() => toggleSelect(profile.id)} className="rounded border-gray-600 accent-yellow-500" />
                    <span className="font-semibold text-white text-sm flex-1">🪟 {profile.name}</span>
                    <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${botStatusColors[profile.botStatus]}`}>{profile.botStatus.toUpperCase()}</span>
                  </div>

                  {hashDups.length > 0 && (
                    <div className="mb-3 flex items-center gap-1.5 text-xs text-red-400 bg-red-500/10 rounded-lg px-2 py-1.5">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      Server Hash duplicate detected!
                    </div>
                  )}

                  {/* Info */}
                  <div className="space-y-1.5 mb-3">
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Account:</span>
                      <span className="text-gray-200">{account?.username || 'Not linked'}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Site:</span>
                      <span className={siteColors[profile.site]}>{profile.site}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Balance:</span>
                      <span className="text-green-400 font-mono">${profile.balance.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Active Game:</span>
                      <span className="text-gray-200">{profile.activeGame || '—'}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Profit:</span>
                      <span className={`font-mono font-semibold ${profile.profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>{profile.profit >= 0 ? '+' : ''}${profile.profit.toFixed(3)}</span>
                    </div>
                    <div className="flex justify-between text-xs">
                      <span className="text-gray-400">Bets / Wins:</span>
                      <span className="text-gray-200">{profile.bets} / {profile.wins}</span>
                    </div>
                  </div>

                  <div className="text-[10px] text-gray-600 font-mono mb-3 truncate">{profile.id}</div>

                  {/* Seeds */}
                  <div className="space-y-1.5 mb-3 border-t border-gray-700/50 pt-3">
                    {(['serverHash', 'clientSeed'] as const).map(field => (
                      <div key={field} className="flex items-center gap-1.5">
                        <span className="text-[10px] text-gray-500 w-16 shrink-0">{field === 'serverHash' ? 'Srv Hash' : 'Cli Seed'}:</span>
                        <input
                          value={profile[field]}
                          onChange={e => updateProfile(profile.id, { [field]: e.target.value })}
                          className="flex-1 px-2 py-1 bg-gray-700/50 border border-gray-600/50 rounded text-[10px] text-gray-300 font-mono outline-none focus:border-yellow-500/50 min-w-0"
                        />
                        <button onClick={() => updateProfile(profile.id, { [field]: field === 'serverHash' ? generateHash() : generateSeed() })} className="shrink-0 text-gray-400 hover:text-yellow-400 transition-colors" title="New">
                          <RefreshCw className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>

                  {/* CDP */}
                  <div className="flex items-center gap-2 mb-3 text-[10px]">
                    <span className="text-gray-500">🔗 CDP:</span>
                    <span className="text-blue-400 font-mono">http://localhost:{profile.cdpPort}</span>
                  </div>

                  {/* Actions */}
                  <div className="flex gap-1.5 border-t border-gray-700/50 pt-3">
                    {profile.botStatus === 'Running' ? (
                      <button onClick={() => stopBot(profile.id)} className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-red-500/20 hover:bg-red-500/30 text-red-400 text-xs rounded-lg border border-red-500/30 transition-colors">
                        <Square className="w-3 h-3" /> Stop
                      </button>
                    ) : (
                      <button onClick={() => setStartBotProfile(profile)} className="flex-1 flex items-center justify-center gap-1 py-1.5 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-xs rounded-lg border border-green-500/30 transition-colors">
                        <Play className="w-3 h-3" /> Start
                      </button>
                    )}
                    <button className="px-2.5 py-1.5 bg-gray-700/50 hover:bg-gray-700 text-gray-400 hover:text-yellow-400 text-xs rounded-lg transition-colors" title="Withdraw">
                      <DollarSign className="w-3 h-3" />
                    </button>
                    <button className="px-2.5 py-1.5 bg-gray-700/50 hover:bg-gray-700 text-gray-400 hover:text-blue-400 text-xs rounded-lg transition-colors" title="Open Browser">
                      <Globe className="w-3 h-3" />
                    </button>
                    <button onClick={() => removeProfile(profile.id)} className="px-2.5 py-1.5 bg-gray-700/50 hover:bg-red-500/20 text-gray-400 hover:text-red-400 text-xs rounded-lg transition-colors" title="Delete">
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </>
      )}

      {startBotProfile && <StartBotModal profile={startBotProfile} onClose={() => setStartBotProfile(null)} />}
    </div>
  );
}
