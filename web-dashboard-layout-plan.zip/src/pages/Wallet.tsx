import { useState } from 'react';
import { useStore, Site } from '../store';
import { Copy, QrCode } from 'lucide-react';

const cryptoCurrencies: Record<Site, string[]> = {
  'roobet.party': ['ETH', 'BTC', 'LTC', 'USDT'],
  'gamdom.win': ['ETH', 'BTC', 'USDT'],
  'stake.pet': ['ETH', 'BTC', 'LTC', 'USDT'],
};

const mockAddresses: Record<string, string> = {
  ETH: '0x4E490b8871C874b84935e6128A21595C2Dd5710d',
  BTC: 'bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh',
  LTC: 'LYWKqJhtkcerdXaW87XKmkeBJnvwgtaK4b',
  USDT: '0x4E490b8871C874b84935e6128A21595C2Dd5710d',
};

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = () => {
    navigator.clipboard.writeText(text).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  return (
    <button onClick={handleCopy} className={`flex items-center gap-1 px-2.5 py-1 text-[10px] rounded border transition-all ${copied ? 'bg-green-500/20 text-green-400 border-green-500/40' : 'bg-gray-700/50 text-gray-400 hover:text-white border-gray-600/50'}`}>
      <Copy className="w-3 h-3" /> {copied ? 'Copied!' : 'Copy'}
    </button>
  );
}

function QRCodeDisplay({ address }: { address: string }) {
  // Simple QR-like visual representation
  const hash = address.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const grid = Array.from({ length: 10 }, (_, r) =>
    Array.from({ length: 10 }, (_, c) => ((hash * (r + 1) * (c + 1)) % 7) < 3)
  );
  return (
    <div className="bg-white p-2 rounded-lg inline-block">
      {grid.map((row, r) => (
        <div key={r} className="flex">
          {row.map((filled, c) => (
            <div key={c} className={`w-2.5 h-2.5 ${filled ? 'bg-black' : 'bg-white'}`} />
          ))}
        </div>
      ))}
    </div>
  );
}

export default function Wallet() {
  const { activeSite, profiles, accounts } = useStore();
  const [selectedSite, setSelectedSite] = useState<Site>(activeSite);
  const [selectedCurrency, setSelectedCurrency] = useState('ETH');
  const [activeTab, setActiveTab] = useState<'deposit' | 'history'>('deposit');

  const siteProfiles = profiles.filter(p => p.site === selectedSite);
  const currencies = cryptoCurrencies[selectedSite];

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div>
        <h1 className="text-2xl font-bold text-white">Wallet</h1>
        <p className="text-gray-400 text-sm mt-1">Deposit addresses and wallet management</p>
      </div>

      {/* Site Selector */}
      <div className="flex gap-2">
        {(['roobet.party', 'gamdom.win', 'stake.pet'] as Site[]).map(site => (
          <button key={site} onClick={() => setSelectedSite(site)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border ${selectedSite === site ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>{site}</button>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-2">
        {(['deposit', 'history'] as const).map(tab => (
          <button key={tab} onClick={() => setActiveTab(tab)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border capitalize ${activeTab === tab ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>{tab === 'deposit' ? '📥 Deposit' : '📤 Withdraw History'}</button>
        ))}
      </div>

      {activeTab === 'deposit' && (
        <>
          {/* Currency Selector */}
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-400">Currency:</span>
            {currencies.map(c => (
              <button key={c} onClick={() => setSelectedCurrency(c)} className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${selectedCurrency === c ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>{c}</button>
            ))}
          </div>

          {/* Profile Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {siteProfiles.map(profile => {
              const account = accounts.find(a => a.id === profile.accountId);
              const address = mockAddresses[selectedCurrency] || '';
              return (
                <div key={profile.id} className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="font-semibold text-white text-sm">{profile.name}</div>
                      <div className="text-xs text-gray-400">{account?.username || 'No account'}</div>
                    </div>
                    <div className="text-right">
                      <div className="text-green-400 font-mono font-bold">${profile.balance.toFixed(2)}</div>
                      <div className="text-[10px] text-gray-500">Balance</div>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <QRCodeDisplay address={address} />
                  </div>

                  <div>
                    <div className="text-[10px] text-gray-500 mb-1">{selectedCurrency} Deposit Address</div>
                    <div className="flex items-center gap-2 bg-gray-700/50 rounded-lg px-2 py-1.5">
                      <span className="text-[10px] text-gray-300 font-mono flex-1 truncate">{address}</span>
                      <CopyButton text={address} />
                    </div>
                  </div>

                  <div className="text-[10px] text-gray-600 text-center">
                    Only send {selectedCurrency} to this address
                  </div>
                </div>
              );
            })}
            {siteProfiles.length === 0 && (
              <div className="col-span-3 text-center py-12 text-gray-500">No profiles for {selectedSite}</div>
            )}
          </div>
        </>
      )}

      {activeTab === 'history' && (
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-6 text-center text-gray-500">
          <QrCode className="w-12 h-12 mx-auto mb-3 opacity-30" />
          <p>Withdrawal history is shown in the Withdrawal page</p>
        </div>
      )}
    </div>
  );
}
