import { useState } from 'react';
import { Search, Download, Upload, Archive, Eye, Globe, Plus, X } from 'lucide-react';
import { useStore, Account, Site, AccountStatus } from '../store';
import { v4 as uuidv4 } from 'uuid';

const statusColors: Record<AccountStatus, string> = {
  'Active': 'bg-green-500/20 text-green-400 border-green-500/40',
  'Banned': 'bg-red-500/20 text-red-400 border-red-500/40',
  'Unverified': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
  'Archived': 'bg-gray-500/20 text-gray-400 border-gray-500/40',
  'Low Balance': 'bg-orange-500/20 text-orange-400 border-orange-500/40',
};

const siteColors: Record<Site, string> = {
  'roobet.party': 'text-yellow-400',
  'gamdom.win': 'text-green-400',
  'stake.pet': 'text-blue-400',
};

export default function Accounts() {
  const { accounts, addAccount, archiveAccount, activeSite } = useStore();
  const [filterSite, setFilterSite] = useState<Site | 'all'>('all');
  const [filterStatus, setFilterStatus] = useState<AccountStatus | 'all'>('all');
  const [search, setSearch] = useState('');
  const [selectedAccount, setSelectedAccount] = useState<Account | null>(null);
  const [showAdd, setShowAdd] = useState(false);
  const [newAcc, setNewAcc] = useState({ email: '', username: '', password: '', site: activeSite as Site });

  const filtered = accounts.filter(a => {
    if (a.status === 'Archived' && filterStatus !== 'Archived') return false;
    if (filterSite !== 'all' && a.site !== filterSite) return false;
    if (filterStatus !== 'all' && a.status !== filterStatus) return false;
    if (search && !a.email.includes(search) && !a.username.includes(search)) return false;
    return true;
  });

  const handleAdd = () => {
    if (!newAcc.email || !newAcc.username || !newAcc.password) return;
    addAccount({
      id: uuidv4(),
      ...newAcc,
      balance: 0,
      status: 'Unverified',
      profileId: '',
      createdOn: new Date().toISOString().split('T')[0],
      lastActive: new Date().toISOString().split('T')[0],
      totalProfit: 0,
      totalBets: 0,
      totalWins: 0,
    });
    setShowAdd(false);
    setNewAcc({ email: '', username: '', password: '', site: activeSite });
  };

  const exportCSV = () => {
    const rows = [['Email', 'Username', 'Password', 'Site', 'Balance', 'Status', 'Created On']];
    accounts.forEach(a => rows.push([a.email, a.username, a.password, a.site, String(a.balance), a.status, a.createdOn]));
    const csv = rows.map(r => r.join(',')).join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const el = document.createElement('a');
    el.href = url; el.download = 'accounts.csv'; el.click();
  };

  return (
    <div className="flex-1 flex flex-col overflow-hidden">
      <div className="p-6 space-y-5 overflow-y-auto flex-1">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-white">Accounts</h1>
            <p className="text-xs text-gray-400 mt-1">⚠️ Accounts are NEVER deleted — only archived permanently</p>
          </div>
          <div className="flex gap-2">
            <button onClick={exportCSV} className="flex items-center gap-2 px-3 py-2 text-xs bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg border border-gray-600 transition-colors">
              <Download className="w-3.5 h-3.5" /> Export CSV
            </button>
            <button className="flex items-center gap-2 px-3 py-2 text-xs bg-gray-700 hover:bg-gray-600 text-gray-300 rounded-lg border border-gray-600 transition-colors">
              <Upload className="w-3.5 h-3.5" /> Import CSV
            </button>
            <button onClick={() => setShowAdd(true)} className="flex items-center gap-2 px-3 py-2 text-xs bg-yellow-500 hover:bg-yellow-400 text-black font-semibold rounded-lg transition-colors">
              <Plus className="w-3.5 h-3.5" /> Add Account
            </button>
          </div>
        </div>

        {/* Filters */}
        <div className="flex gap-3 flex-wrap">
          <div className="relative">
            <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-500" />
            <input
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search email / username..."
              className="pl-8 pr-3 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-gray-200 outline-none focus:border-yellow-500/50 w-56"
            />
          </div>
          <select value={filterSite} onChange={e => setFilterSite(e.target.value as any)} className="px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-gray-200 outline-none">
            <option value="all">All Sites</option>
            <option value="roobet.party">roobet.party</option>
            <option value="gamdom.win">gamdom.win</option>
            <option value="stake.pet">stake.pet</option>
          </select>
          <select value={filterStatus} onChange={e => setFilterStatus(e.target.value as any)} className="px-3 py-1.5 bg-gray-800 border border-gray-700 rounded-lg text-xs text-gray-200 outline-none">
            <option value="all">All Status</option>
            <option value="Active">Active</option>
            <option value="Banned">Banned</option>
            <option value="Unverified">Unverified</option>
            <option value="Low Balance">Low Balance</option>
            <option value="Archived">Archived</option>
          </select>
          <div className="ml-auto text-xs text-gray-500 flex items-center">{filtered.length} accounts</div>
        </div>

        {/* Table */}
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-xs">
              <thead>
                <tr className="border-b border-gray-700/50 bg-gray-900/50">
                  {['#', 'Site', 'Email', 'Username', 'Password', 'Balance', 'Status', 'Profile ID', 'Created', 'Last Active', 'Profit', 'Actions'].map(h => (
                    <th key={h} className="text-left px-3 py-3 text-gray-400 font-medium whitespace-nowrap">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((acc, i) => (
                  <tr key={acc.id} className="border-b border-gray-700/30 hover:bg-gray-700/20 transition-colors">
                    <td className="px-3 py-2.5 text-gray-500">{i + 1}</td>
                    <td className="px-3 py-2.5">
                      <span className={`font-medium ${siteColors[acc.site]}`}>{acc.site.split('.')[0]}</span>
                    </td>
                    <td className="px-3 py-2.5 text-gray-200 font-mono text-[11px]">{acc.email}</td>
                    <td className="px-3 py-2.5 text-gray-300">{acc.username}</td>
                    <td className="px-3 py-2.5 text-gray-500 font-mono">{'•'.repeat(8)}</td>
                    <td className="px-3 py-2.5 text-green-400 font-mono font-semibold">${acc.balance.toFixed(2)}</td>
                    <td className="px-3 py-2.5">
                      <span className={`px-2 py-0.5 rounded-full border text-[10px] font-medium ${statusColors[acc.status]}`}>{acc.status}</span>
                    </td>
                    <td className="px-3 py-2.5 text-gray-500 font-mono text-[10px] max-w-[100px] truncate">{acc.profileId || '—'}</td>
                    <td className="px-3 py-2.5 text-gray-500">{acc.createdOn}</td>
                    <td className="px-3 py-2.5 text-gray-500">{acc.lastActive}</td>
                    <td className={`px-3 py-2.5 font-mono font-semibold ${acc.totalProfit >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                      {acc.totalProfit >= 0 ? '+' : ''}${acc.totalProfit.toFixed(2)}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-1">
                        <button onClick={() => setSelectedAccount(acc)} className="p-1 text-gray-400 hover:text-white transition-colors" title="View">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button className="p-1 text-gray-400 hover:text-blue-400 transition-colors" title="Open Browser">
                          <Globe className="w-3.5 h-3.5" />
                        </button>
                        {acc.status !== 'Archived' && (
                          <button onClick={() => archiveAccount(acc.id)} className="p-1 text-gray-400 hover:text-orange-400 transition-colors" title="Archive">
                            <Archive className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Add Account Modal */}
      {showAdd && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gray-800 border border-gray-600 rounded-2xl p-6 w-96 shadow-2xl">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-white">Add Account</h3>
              <button onClick={() => setShowAdd(false)} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-3">
              {(['email', 'username', 'password'] as const).map(field => (
                <div key={field}>
                  <label className="text-xs text-gray-400 capitalize mb-1 block">{field}</label>
                  <input
                    type={field === 'password' ? 'password' : 'text'}
                    value={newAcc[field]}
                    onChange={e => setNewAcc(p => ({ ...p, [field]: e.target.value }))}
                    className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none focus:border-yellow-500/50"
                  />
                </div>
              ))}
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Site</label>
                <select value={newAcc.site} onChange={e => setNewAcc(p => ({ ...p, site: e.target.value as Site }))} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none">
                  <option value="roobet.party">roobet.party</option>
                  <option value="gamdom.win">gamdom.win</option>
                  <option value="stake.pet">stake.pet</option>
                </select>
              </div>
            </div>
            <button onClick={handleAdd} className="w-full mt-4 py-2.5 bg-yellow-500 hover:bg-yellow-400 text-black font-bold rounded-xl transition-colors">
              Add Account
            </button>
          </div>
        </div>
      )}

      {/* Account Detail Modal */}
      {selectedAccount && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50">
          <div className="bg-gray-800 border border-gray-600 rounded-2xl p-6 w-[520px] shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-bold text-white">Account Detail — {selectedAccount.username}</h3>
              <button onClick={() => setSelectedAccount(null)} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="grid grid-cols-2 gap-3 text-sm">
              {[
                ['Site', selectedAccount.site],
                ['Email', selectedAccount.email],
                ['Username', selectedAccount.username],
                ['Password', selectedAccount.password],
                ['Balance', `$${selectedAccount.balance.toFixed(2)}`],
                ['Status', selectedAccount.status],
                ['Profile ID', selectedAccount.profileId || 'Not linked'],
                ['Created On', selectedAccount.createdOn],
                ['Last Active', selectedAccount.lastActive],
                ['Total Bets', selectedAccount.totalBets],
                ['Total Wins', selectedAccount.totalWins],
                ['Total Profit', `$${selectedAccount.totalProfit.toFixed(2)}`],
              ].map(([k, v]) => (
                <div key={k} className="bg-gray-700/50 rounded-lg px-3 py-2">
                  <div className="text-[10px] text-gray-500 mb-0.5">{k}</div>
                  <div className="text-gray-200 font-mono text-xs break-all">{String(v)}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
