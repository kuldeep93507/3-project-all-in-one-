import { useState } from 'react';
import { useStore, Site } from '../store';
import { v4 as uuidv4 } from 'uuid';
import { DollarSign, CheckCircle, Clock, XCircle, Send } from 'lucide-react';

const statusColors = {
  'Pending': 'bg-yellow-500/20 text-yellow-400 border-yellow-500/40',
  'Submitted': 'bg-blue-500/20 text-blue-400 border-blue-500/40',
  'Confirmed': 'bg-green-500/20 text-green-400 border-green-500/40',
  'Failed': 'bg-red-500/20 text-red-400 border-red-500/40',
};

const statusIcon = {
  'Pending': <Clock className="w-3 h-3" />,
  'Submitted': <Send className="w-3 h-3" />,
  'Confirmed': <CheckCircle className="w-3 h-3" />,
  'Failed': <XCircle className="w-3 h-3" />,
};

const DEFAULT_ADDRESS = '0x4E490b8871C874b84935e6128A21595C2Dd5710d';

export default function Withdrawal() {
  const { activeSite, profiles, accounts, withdrawals, addWithdrawal } = useStore();
  const [selectedSite, setSelectedSite] = useState<Site>(activeSite);
  const [selected, setSelected] = useState<string[]>([]);
  const [globalAddress, setGlobalAddress] = useState(DEFAULT_ADDRESS);
  const [currency, setCurrency] = useState('ETH');
  const [amounts, setAmounts] = useState<Record<string, string>>({});
  const [withdrawingMap, setWithdrawingMap] = useState<Record<string, boolean>>({});
  const [showHistory, setShowHistory] = useState(false);

  const siteProfiles = profiles.filter(p => p.site === selectedSite);

  const toggleSelect = (id: string) => setSelected(s => s.includes(id) ? s.filter(x => x !== id) : [...s, id]);
  const toggleAll = () => setSelected(selected.length === siteProfiles.length ? [] : siteProfiles.map(p => p.id));

  const handleWithdraw = (profileId: string) => {
    const profile = profiles.find(p => p.id === profileId);
    if (!profile) return;
    const amount = parseFloat(amounts[profileId] || String(profile.balance));
    if (!amount || amount <= 0) return;

    setWithdrawingMap(m => ({ ...m, [profileId]: true }));
    setTimeout(() => {
      addWithdrawal({
        id: uuidv4(),
        profileId,
        site: selectedSite,
        amount,
        currency,
        address: globalAddress,
        time: new Date().toLocaleString(),
        status: 'Submitted',
      });
      setWithdrawingMap(m => ({ ...m, [profileId]: false }));
    }, 1500);
  };

  const handleWithdrawSelected = () => {
    const targets = selected.length > 0 ? selected : siteProfiles.map(p => p.id);
    targets.forEach(id => handleWithdraw(id));
  };

  return (
    <div className="flex-1 overflow-y-auto p-6 space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Withdrawal</h1>
          <p className="text-gray-400 text-sm mt-1">Withdraw profits from all accounts</p>
        </div>
        <button onClick={() => setShowHistory(!showHistory)} className={`px-4 py-2 text-xs rounded-xl border transition-colors ${showHistory ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>
          {showHistory ? 'Withdrawal Table' : 'History'}
        </button>
      </div>

      {/* Site Selector */}
      <div className="flex gap-2">
        {(['roobet.party', 'gamdom.win', 'stake.pet'] as Site[]).map(site => (
          <button key={site} onClick={() => setSelectedSite(site)} className={`px-4 py-2 rounded-xl text-sm font-medium transition-all border ${selectedSite === site ? 'bg-yellow-500/20 border-yellow-500/50 text-yellow-300' : 'bg-gray-800 border-gray-700 text-gray-400 hover:text-white'}`}>{site}</button>
        ))}
      </div>

      {!showHistory ? (
        <>
          {/* Global Settings */}
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4 space-y-3">
            <h3 className="font-semibold text-white text-sm">⚙️ Withdrawal Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <div className="md:col-span-2">
                <label className="text-xs text-gray-400 mb-1 block">Withdrawal Address</label>
                <input value={globalAddress} onChange={e => setGlobalAddress(e.target.value)} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none focus:border-yellow-500/50 font-mono text-xs" />
              </div>
              <div>
                <label className="text-xs text-gray-400 mb-1 block">Currency</label>
                <select value={currency} onChange={e => setCurrency(e.target.value)} className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-lg text-sm text-white outline-none">
                  {['ETH', 'BTC', 'LTC', 'USDT'].map(c => <option key={c} value={c}>{c}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Bulk Actions */}
          <div className="flex items-center gap-3 flex-wrap">
            <input type="checkbox" checked={selected.length === siteProfiles.length} onChange={toggleAll} className="accent-yellow-500" />
            <span className="text-xs text-gray-400">{selected.length > 0 ? `${selected.length} selected` : 'Select All'}</span>
            <button onClick={handleWithdrawSelected} className="flex items-center gap-2 px-4 py-2 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-semibold rounded-xl transition-colors">
              <DollarSign className="w-3.5 h-3.5" /> Withdraw Selected
            </button>
            <button onClick={() => { setSelected(siteProfiles.map(p => p.id)); setTimeout(handleWithdrawSelected, 100); }} className="flex items-center gap-2 px-4 py-2 bg-green-500/20 hover:bg-green-500/30 text-green-400 text-xs rounded-xl border border-green-500/30 transition-colors">
              <DollarSign className="w-3.5 h-3.5" /> Withdraw All
            </button>
          </div>

          {/* Table */}
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="border-b border-gray-700/50 bg-gray-900/30">
                    <th className="text-left px-3 py-3 text-gray-400 font-medium w-8"></th>
                    {['Profile', 'Account', 'Site', 'Balance', 'Address', 'Amount', 'Action'].map(h => (
                      <th key={h} className="text-left px-3 py-3 text-gray-400 font-medium">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {siteProfiles.map(profile => {
                    const account = accounts.find(a => a.id === profile.accountId);
                    const isWithdrawing = withdrawingMap[profile.id];
                    return (
                      <tr key={profile.id} className="border-b border-gray-700/30 hover:bg-gray-700/20">
                        <td className="px-3 py-3">
                          <input type="checkbox" checked={selected.includes(profile.id)} onChange={() => toggleSelect(profile.id)} className="accent-yellow-500" />
                        </td>
                        <td className="px-3 py-3 text-gray-200 font-medium">{profile.name}</td>
                        <td className="px-3 py-3 text-gray-400">{account?.username || '—'}</td>
                        <td className="px-3 py-3 text-yellow-400">{profile.site}</td>
                        <td className="px-3 py-3 text-green-400 font-mono font-semibold">${profile.balance.toFixed(2)}</td>
                        <td className="px-3 py-3 text-gray-500 font-mono text-[10px] max-w-[140px] truncate">{globalAddress}</td>
                        <td className="px-3 py-3">
                          <div className="flex items-center gap-1.5">
                            <input
                              type="number"
                              value={amounts[profile.id] || ''}
                              onChange={e => setAmounts(m => ({ ...m, [profile.id]: e.target.value }))}
                              placeholder={`Max ${profile.balance.toFixed(2)}`}
                              className="w-20 px-2 py-1 bg-gray-700/50 border border-gray-600/50 rounded text-gray-200 outline-none focus:border-yellow-500/50 text-[10px]"
                            />
                          </div>
                        </td>
                        <td className="px-3 py-3">
                          <button
                            onClick={() => handleWithdraw(profile.id)}
                            disabled={isWithdrawing || profile.balance <= 0}
                            className={`flex items-center gap-1 px-2.5 py-1.5 text-[10px] rounded border transition-colors ${isWithdrawing ? 'bg-gray-700 text-gray-500 border-gray-600' : 'bg-yellow-500/20 hover:bg-yellow-500/30 text-yellow-400 border-yellow-500/30'} disabled:opacity-40`}
                          >
                            {isWithdrawing ? (
                              <><div className="w-2.5 h-2.5 border border-yellow-400 border-t-transparent rounded-full animate-spin" /> Sending</>
                            ) : (
                              <><DollarSign className="w-3 h-3" /> Withdraw</>
                            )}
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                  {siteProfiles.length === 0 && (
                    <tr><td colSpan={8} className="text-center py-8 text-gray-500">No profiles for {selectedSite}</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        /* History */
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl overflow-hidden">
          <table className="w-full text-xs">
            <thead>
              <tr className="border-b border-gray-700/50 bg-gray-900/30">
                {['Profile', 'Site', 'Amount', 'Currency', 'Address', 'Time', 'Status'].map(h => (
                  <th key={h} className="text-left px-4 py-3 text-gray-400 font-medium">{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {withdrawals.map(w => (
                <tr key={w.id} className="border-b border-gray-700/30 hover:bg-gray-700/20">
                  <td className="px-4 py-3 text-gray-200">{w.profileId}</td>
                  <td className="px-4 py-3 text-yellow-400">{w.site}</td>
                  <td className="px-4 py-3 text-green-400 font-mono font-semibold">${w.amount.toFixed(4)}</td>
                  <td className="px-4 py-3 text-gray-300">{w.currency}</td>
                  <td className="px-4 py-3 text-gray-500 font-mono text-[10px] max-w-[150px] truncate">{w.address}</td>
                  <td className="px-4 py-3 text-gray-500">{w.time}</td>
                  <td className="px-4 py-3">
                    <span className={`flex items-center gap-1.5 px-2 py-0.5 rounded-full border text-[10px] font-medium w-fit ${statusColors[w.status]}`}>
                      {statusIcon[w.status]} {w.status}
                    </span>
                  </td>
                </tr>
              ))}
              {withdrawals.length === 0 && (
                <tr><td colSpan={7} className="text-center py-8 text-gray-500">No withdrawal history yet</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
