import { useState } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import { TrendingUp, Users, Bot, Target, DollarSign, Activity } from 'lucide-react';
import { useStore } from '../store';
import type { Site } from '../store';

const sites: Site[] = ['roobet.party', 'gamdom.win', 'stake.pet'];

const siteColors: Record<Site, string> = {
  'roobet.party': '#f59e0b',
  'gamdom.win': '#22c55e',
  'stake.pet': '#3b82f6',
};

const generateChartData = (range: string) => {
  const points = range === '24h' ? 24 : range === '7d' ? 7 : 30;
  let profit = 0;
  return Array.from({ length: points }, (_, i) => {
    const delta = (Math.random() - 0.4) * 5;
    profit += delta;
    return {
      label: range === '24h' ? `${i}:00` : range === '7d' ? `Day ${i + 1}` : `${i + 1}`,
      profit: parseFloat(profit.toFixed(2)),
      bets: Math.floor(Math.random() * 50) + 10,
    };
  });
};

const pieData = [
  { name: 'Limbo', value: 35, color: '#f59e0b' },
  { name: 'Dice', value: 25, color: '#22c55e' },
  { name: 'Mines', value: 20, color: '#3b82f6' },
  { name: 'Crash', value: 12, color: '#a855f7' },
  { name: 'Others', value: 8, color: '#6b7280' },
];

export default function Dashboard() {
  const { accounts, profiles, betResults, rewardClaims } = useStore();
  const [chartRange, setChartRange] = useState<'24h' | '7d' | '30d'>('24h');
  const [chartData] = useState(() => generateChartData('24h'));
  const [data7d] = useState(() => generateChartData('7d'));
  const [data30d] = useState(() => generateChartData('30d'));

  const currentData = chartRange === '24h' ? chartData : chartRange === '7d' ? data7d : data30d;

  const totalAccounts = accounts.length;
  const activeBots = profiles.filter(p => p.botStatus === 'Running').length;
  const totalBetsToday = betResults.length;
  const totalWinsToday = betResults.filter(b => b.result === 'WIN').length;
  const netProfitToday = betResults.reduce((sum, b) => sum + b.profit, 0);
  const allTimeProfit = accounts.reduce((sum, a) => sum + a.totalProfit, 0);

  const online = accounts.filter(a => a.status === 'Active').length;
  const banned = accounts.filter(a => a.status === 'Banned').length;
  const lowBal = accounts.filter(a => a.status === 'Low Balance').length;
  const offline = accounts.filter(a => a.status === 'Archived' || a.status === 'Unverified').length;

  const perSiteStats = sites.map(site => ({
    site,
    accounts: accounts.filter(a => a.site === site).length,
    bots: profiles.filter(p => p.site === site && p.botStatus === 'Running').length,
    profit: profiles.filter(p => p.site === site).reduce((s, p) => s + p.profit, 0),
  }));

  const statCards = [
    { label: 'Total Accounts', value: totalAccounts, icon: <Users className="w-5 h-5" />, color: 'text-blue-400', bg: 'bg-blue-500/10 border-blue-500/20' },
    { label: 'Active Bots', value: activeBots, icon: <Bot className="w-5 h-5" />, color: 'text-green-400', bg: 'bg-green-500/10 border-green-500/20' },
    { label: 'Total Bets Today', value: totalBetsToday, icon: <Activity className="w-5 h-5" />, color: 'text-purple-400', bg: 'bg-purple-500/10 border-purple-500/20' },
    { label: 'Total Wins Today', value: totalWinsToday, icon: <Target className="w-5 h-5" />, color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20' },
    { label: 'Net Profit Today', value: `$${netProfitToday.toFixed(2)}`, icon: <TrendingUp className="w-5 h-5" />, color: netProfitToday >= 0 ? 'text-green-400' : 'text-red-400', bg: netProfitToday >= 0 ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20' },
    { label: 'All Time Profit', value: `$${allTimeProfit.toFixed(2)}`, icon: <DollarSign className="w-5 h-5" />, color: allTimeProfit >= 0 ? 'text-green-400' : 'text-red-400', bg: allTimeProfit >= 0 ? 'bg-green-500/10 border-green-500/20' : 'bg-red-500/10 border-red-500/20' },
  ];

  return (
    <div className="p-6 space-y-6 overflow-y-auto flex-1">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Dashboard</h1>
          <p className="text-gray-400 text-sm mt-1">Real-time overview of all bots and accounts</p>
        </div>
        <div className="flex items-center gap-2 text-xs text-gray-400">
          <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
          Live Updates
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-4">
        {statCards.map((card) => (
          <div key={card.label} className={`rounded-xl border p-4 ${card.bg}`}>
            <div className={`${card.color} mb-2`}>{card.icon}</div>
            <div className="text-2xl font-bold text-white">{card.value}</div>
            <div className="text-xs text-gray-400 mt-1">{card.label}</div>
          </div>
        ))}
      </div>

      {/* Per-Site Stats */}
      <div className="grid grid-cols-3 gap-4">
        {perSiteStats.map(({ site, accounts: acc, bots, profit }) => (
          <div key={site} className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: siteColors[site] }} />
              <span className="font-semibold text-sm" style={{ color: siteColors[site] }}>{site}</span>
            </div>
            <div className="grid grid-cols-3 gap-2 text-center">
              <div>
                <div className="text-lg font-bold text-white">{acc}</div>
                <div className="text-[10px] text-gray-500">Accounts</div>
              </div>
              <div>
                <div className="text-lg font-bold text-white">{bots}</div>
                <div className="text-[10px] text-gray-500">Bots</div>
              </div>
              <div>
                <div className={`text-lg font-bold ${profit >= 0 ? 'text-green-400' : 'text-red-400'}`}>${profit.toFixed(1)}</div>
                <div className="text-[10px] text-gray-500">Profit</div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
        {/* Profit Chart */}
        <div className="xl:col-span-2 bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold text-white">Profit / Loss</h2>
            <div className="flex gap-1">
              {(['24h', '7d', '30d'] as const).map(r => (
                <button
                  key={r}
                  onClick={() => setChartRange(r)}
                  className={`px-2.5 py-1 text-xs rounded-lg transition-all ${chartRange === r ? 'bg-yellow-500 text-black font-semibold' : 'bg-gray-700 text-gray-400 hover:text-white'}`}
                >
                  {r}
                </button>
              ))}
            </div>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={currentData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="label" tick={{ fill: '#9ca3af', fontSize: 11 }} />
              <YAxis tick={{ fill: '#9ca3af', fontSize: 11 }} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px', color: '#fff' }} />
              <Line type="monotone" dataKey="profit" stroke="#f59e0b" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Pie Chart */}
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
          <h2 className="font-semibold text-white mb-4">Win Rate by Game</h2>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={50} outerRadius={80} dataKey="value">
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color} />
                ))}
              </Pie>
              <Legend formatter={(v) => <span style={{ color: '#9ca3af', fontSize: 11 }}>{v}</span>} />
              <Tooltip contentStyle={{ backgroundColor: '#1f2937', border: '1px solid #374151', borderRadius: '8px', color: '#fff' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
        {/* Live Bets Feed */}
        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-semibold text-white flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-green-400 animate-pulse" />
              Live Bets Feed
            </h2>
            <span className="text-xs text-gray-500">{betResults.length} bets</span>
          </div>
          <div className="space-y-1 max-h-56 overflow-y-auto">
            {betResults.slice(0, 15).map(b => (
              <div key={b.id} className={`flex items-center gap-2 text-xs px-2 py-1.5 rounded-lg ${b.result === 'WIN' ? 'bg-green-500/10 border border-green-500/20' : 'bg-red-500/10 border border-red-500/20'}`}>
                <div className={`w-1.5 h-1.5 rounded-full shrink-0 ${b.result === 'WIN' ? 'bg-green-400' : 'bg-red-400'}`} />
                <span className="text-gray-400 shrink-0">{b.site.split('.')[0]}</span>
                <span className="text-gray-300 shrink-0">{b.profile}</span>
                <span className="text-gray-400 shrink-0">{b.game}</span>
                <span className="text-gray-300 shrink-0">${b.betAmount.toFixed(2)}</span>
                <span className={`ml-auto font-mono font-semibold ${b.result === 'WIN' ? 'text-green-400' : 'text-red-400'}`}>
                  {b.profit >= 0 ? '+' : ''}${b.profit.toFixed(3)}
                </span>
                <span className="text-gray-600">{b.time}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Account Health + Recent Rewards */}
        <div className="space-y-4">
          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
            <h2 className="font-semibold text-white mb-3">Account Health</h2>
            <div className="grid grid-cols-2 gap-3">
              {[
                { color: 'bg-green-400', label: 'Online', count: online },
                { color: 'bg-red-400', label: 'Banned', count: banned },
                { color: 'bg-yellow-400', label: 'Low Balance', count: lowBal },
                { color: 'bg-gray-500', label: 'Offline', count: offline },
              ].map(({ color, label, count }) => (
                <div key={label} className="flex items-center gap-2 bg-gray-700/30 rounded-lg px-3 py-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${color}`} />
                  <span className="text-xs text-gray-400">{label}</span>
                  <span className="ml-auto text-sm font-bold text-white">{count}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-4">
            <h2 className="font-semibold text-white mb-3">Recent Rewards Claimed</h2>
            <div className="space-y-2 max-h-32 overflow-y-auto">
              {rewardClaims.slice(0, 5).map(r => (
                <div key={r.id} className="flex items-center gap-2 text-xs bg-gray-700/30 rounded-lg px-3 py-2">
                  <span className="text-purple-400">{r.type}</span>
                  <span className="text-gray-400">{r.site.split('.')[0]}</span>
                  <span className="ml-auto text-green-400 font-mono font-semibold">+${r.amount.toFixed(2)}</span>
                  <span className="text-gray-600">{r.time}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
